# FitPlate – calendar-first meal & workout planner (MVP)

Free, frontend-only React + TypeScript app that plans lunch, dinner and a workout for every day of the week, estimates calories/macros and cost, builds a consolidated shopping list, and compares **demo** nearby stores.
**All nutrition values, stores and prices are sample/estimated demo data. Nothing is live.** Not medical advice.

## Install & run
```bash
npm install
npm run dev        # http://localhost:5173
npm test           # engine unit tests + UI workflow smoke test
npm run typecheck && npm run lint
npm run build      # production build in dist/
```
Deploy the static MVP by uploading `dist/` to any static host (Netlify, Vercel, Cloudflare Pages, GitHub Pages; for SPA routing add a fallback to `index.html`).

## Architecture
```
React UI (pages, components)  →  AppContext (state + persistence)
        ↓                              ↓
   engine/ (pure, deterministic)   services/ (swappable boundaries)
   nutrition, recommendation,      storage · location · stores · pricing · assistant
   planner, shopping, units,       ↓
   matching, store comparison      future backend API (see below)
```
- `src/engine/` – pure TypeScript, no React: `nutritionCalculator`, `mealRecommendation`, `workoutRecommendation`, `weeklyPlanner`, `shoppingListGenerator`, `productMatching`, `storeComparison`, `unitConversion`, `distanceCalculator`.
- `src/services/` – interfaces + mock implementations: `storage/`, `location/`, `stores/`, `pricing/`, `assistant/`.
- `src/config/` – tunable weights (`recommendationWeights.ts`, `storeComparisonWeights.ts`). Product-design settings, **not** medically validated.
- `src/data/` – sample data: `meals.ts`, `ingredients.ts`, `stores.ts`, `products.ts`, `restaurants.ts`, `workouts.ts`.

## How meal recommendations work
1. **Safety gate (never relaxed):** allergies (declared allergens ∪ structured ingredient allergen tags), diet preference, disliked foods.
2. Slot (lunch/dinner) and calorie window (60–130% of the meal target).
3. User constraints: max price per meal, max prep time, cooking preference.
4. Weighted score: nutrition fit, protein fit, budget fit, convenience, preference, variety, nearby price coverage. Missing local price data lowers *confidence* and a small score component but never disqualifies a meal.

Calorie targets use **Mifflin-St Jeor** BMR × activity factor, with a deficit capped at min(20% of TDEE, 500 kcal), a floor (1200 F / 1500 M), and maintenance for under-18s or low BMI. Lunch ≈ 30% and dinner ≈ 35% of the daily estimate.

## How weekly plan generation works
`generateWeek` picks lunch then dinner for Mon–Sun, avoiding repeats (this week and last), then runs a budget pass that swaps the priciest meals for cheaper compatible ones if the weekly grocery budget is exceeded. If constraints are too strict it relaxes only budget → prep time → cooking preference (never safety) and adds a visible warning. Workouts follow a recovery-aware weekly pattern based on active days, level, equipment, preferred duration and recently completed workouts. **Workouts are never computed from food eaten.**

## Location permissions
- Nothing is requested on page load. The prompt offers **Use My Location**, **Enter ZIP Code**, **Not Now**.
- Only `BrowserLocationProvider` touches `navigator.geolocation`; it does a single `getCurrentPosition` (no tracking/history) and handles denied, unavailable, timeout, unsupported and low-accuracy cases.
- Coordinates are rounded to ~1 km before storage and never displayed. ZIP validation handles missing/invalid input.
- **Demo ZIP mapping:** with no geocoder configured, a ZIP maps to a coarse regional centre (clearly labelled demo).
- Profile → Location: update, switch to ZIP, disable local recommendations, **Remove saved location** (also clears the `currentLocationPreference` key).

## Distance
Haversine great-circle distance, labelled "approximate straight-line". It is not driving distance or travel time. If routing is added, keep it in a separate field.

## Store comparison
For each supported store: match each recipe ingredient to a product (`exact` / `mapped` / `uncertain` / `unmatched`), convert units only when compatible, then compute:
- **Package (checkout) cost** – whole packages you must buy.
- **Usage cost** – only the quantity the recipe/list uses (0.4 lb from a 2.5 lb, $10 pack = $1.60 usage, $10 checkout).
- **Cost per serving** – usage ÷ servings (or per planned meal for the weekly basket).
- **Coverage** – priced ingredients ÷ total ingredients. Missing, out-of-stock, unit-incompatible and uncertain items are listed and **never counted as $0**.

Best-value score = weighted price (on ingredients priced at *every* ranked store, for fairness), distance vs. radius, coverage and availability. The headline says "Lowest estimated cost among supported stores" only when every ranked store has ≥90% coverage; otherwise "Lowest price among supported stores with available data" plus a not-definitive warning. Split-store shows store count, estimate, extra straight-line round-trip distance and recommends it only for meaningful savings (≥$5 and ≥10%).

## Sample/mock data locations
Everything in `src/data/` plus `MockStoreProvider`, `MockPricingProvider`, `ZipCodeLocationProvider` (demo ZIP map). Sample products use `priceType: 'sample'` (pantry items `'estimated'`), no retrieval timestamps. `'live'` is only shown if a provider returns it.

## localStorage structure
All keys are prefixed `fitplate:v1:` and written only via `src/services/storage/storageService.ts`: `userProfile`, `currentLocationPreference`, `weeklyPlans` (by Monday date), `weeklyShoppingLists` (removed/checked per week), `favorites`, `completedMeals`, `completedWorkouts`, `weightHistory`, `selectedStores`, `alreadyOwnedIngredients`. Profile → "Delete all saved data" clears everything.

## Extending
**Real place provider:** implement `StoreProvider.findNearby` on a server (Google Places, Foursquare, OSM…), expose `GET /api/stores/nearby`, and create a client `StoreProvider` that calls it; swap it in with `storeService.setProvider()`. Keep API keys on the server.

**Retailer pricing provider:** implement `PricingProvider` (see `KrogerPricingProvider.ts`, a documented placeholder that makes no calls). The server authenticates with the retailer, normalises results to `GroceryPrice` with `priceType: 'live'` and a real `retrievedAt`.

**Why a backend is required:** retailer OAuth client secrets and place-API keys cannot be hidden in browser code, and retailer APIs usually block browser CORS. Never ship credentials in the bundle; never scrape retailer sites.

**Suggested API contracts** (types in `src/types/api.ts`)
- `GET /api/stores/nearby?lat=&lng=&radiusMiles=&chains=` → `{ stores: Store[], provider, generatedAt }`
- `POST /api/prices/compare` `{ storeIds, requirements, servings }` → `{ prices: GroceryPrice[], provider }`
- `POST /api/shopping-list/compare` `{ storeIds, items, mode: 'single'|'split' }` → `{ prices, provider }`
- ZIP geocoder: `GET /api/geocode/zip/:zip` → `{ latitude, longitude, zipCode }`

**Supabase:** implement `StorageService` (`get/set/remove/clearAll`) against Postgres tables mirroring `StorageSchema` (the interface is synchronous today; make it async and `await` in `AppContext`'s `usePersisted`), add Supabase Auth, and keep row-level security per user.

**Optional AI assistant:** `services/assistant/AssistantService.ts` defines structured `AssistantAction`s ("no chicken Tuesday", "$6 dinner", "within 3 miles"). An LLM may only translate text into these actions; `validateAction` and the deterministic engine execute them, so allergies, nutrition values, prices, stores, distances and availability can never be invented or overridden. The app runs with `DisabledAssistant`.

## Accessibility
Semantic landmarks, labelled form fields, skip link, keyboard-operable buttons, dialogs with focus trap/Esc/focus return, coverage and warnings conveyed by text and icons (not colour alone), chart with text alternative and table.

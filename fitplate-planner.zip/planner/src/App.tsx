import { Navigate, Route, Routes } from 'react-router-dom'
import { useApp } from './state/AppContext'
import { Layout } from './components/Layout/Layout'
import CalendarPage from './pages/Calendar'
import ShoppingPage from './pages/Shopping'
import ProgressPage from './pages/Progress'
import ProfilePage from './pages/Profile'
import OnboardingPage from './pages/Onboarding'

export default function App() {
  const { profile } = useApp()
  const onboarded = !!profile?.onboarded
  return (
    <Routes>
      <Route path="/onboarding" element={onboarded ? <Navigate to="/" replace /> : <OnboardingPage />} />
      <Route element={onboarded ? <Layout /> : <Navigate to="/onboarding" replace />}>
        <Route index element={<CalendarPage />} />
        <Route path="shopping" element={<ShoppingPage />} />
        <Route path="progress" element={<ProgressPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

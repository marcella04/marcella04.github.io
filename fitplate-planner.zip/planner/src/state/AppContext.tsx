import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type Dispatch, type ReactNode, type SetStateAction } from 'react'
import type {
  GroceryPrice, MealType, Store, UserLocation, UserProfile, WeeklyPlan,
} from '../types'
import { storage, type ShoppingListState, type StorageKey, type StorageSchema } from '../services/storage/storageService'
import { locationService } from '../services/location/locationService'
import { LocationError } from '../services/location/LocationProvider'
import { storeService } from '../services/stores/StoreService'
import { pricingService } from '../services/pricing/PricingService'
import { meals } from '../data/meals'
import { workouts } from '../data/workouts'
import { generateWeek } from '../engine/weeklyPlanner'
import { compareStores } from '../engine/storeComparison'
import { mondayOf } from '../utils/dates'

function usePersisted<K extends StorageKey>(key: K): [StorageSchema[K], Dispatch<SetStateAction<StorageSchema[K]>>] {
  const [v, setV] = useState<StorageSchema[K]>(() => storage.get(key))
  const first = useRef(true)
  useEffect(() => { if (first.current) { first.current = false; return } storage.set(key, v) }, [key, v])
  return [v, setV]
}

export interface NearbyState { status: 'idle' | 'loading' | 'ready' | 'error'; stores: Store[]; prices: GroceryPrice[]; error?: string }
export type ActionResult = { ok: true } | { ok: false; message: string }

function useAppState() {
  const [profile, setProfileState] = usePersisted('userProfile')
  const [locationPref, setLocationPref] = usePersisted('currentLocationPreference')
  const [plans, setPlans] = usePersisted('weeklyPlans')
  const [shoppingStates, setShoppingStates] = usePersisted('weeklyShoppingLists')
  const [favorites, setFavorites] = usePersisted('favorites')
  const [completedMeals, setCompletedMeals] = usePersisted('completedMeals')
  const [completedWorkouts, setCompletedWorkouts] = usePersisted('completedWorkouts')
  const [weightHistory, setWeightHistory] = usePersisted('weightHistory')
  const [selectedStores, setSelectedStores] = usePersisted('selectedStores')
  const [owned, setOwned] = usePersisted('alreadyOwnedIngredients')
  const [weekStart, setWeekStart] = useState(() => mondayOf(new Date()))
  const [nearby, setNearby] = useState<NearbyState>({ status: 'idle', stores: [], prices: [] })
  const [reloadTick, setReloadTick] = useState(0)

  const loc = locationPref.location
  const localOn = (locationPref.mode === 'browser' || locationPref.mode === 'zip') && !!loc
  const radius = profile?.storeRadiusMiles ?? 5
  useEffect(() => {
    if (!localOn || !loc) { setNearby({ status: 'idle', stores: [], prices: [] }); return }
    let cancelled = false
    setNearby(n => ({ ...n, status: 'loading', error: undefined }))
    ;(async () => {
      try {
        const stores = await storeService.nearby({ latitude: loc.latitude, longitude: loc.longitude, radiusMiles: radius })
        const prices = await pricingService.getPrices(stores)
        if (!cancelled) setNearby({ status: 'ready', stores, prices })
      } catch (e) {
        if (!cancelled) setNearby({ status: 'error', stores: [], prices: [], error: e instanceof Error ? e.message : 'Could not load nearby stores.' })
      }
    })()
    return () => { cancelled = true }
  }, [localOn, loc, radius, reloadTick])

  const coverageByMeal = useMemo(() => {
    if (nearby.status !== 'ready') return undefined
    const out: Record<string, number> = {}
    for (const m of meals) {
      if (!m.ingredients.length) continue
      const r = compareStores({ requirements: m.ingredients, servings: m.servings, stores: nearby.stores, prices: nearby.prices, radiusMiles: radius })
      out[m.id] = Math.max(0, ...r.rows.map(x => x.coveragePercent)) / 100
    }
    return out
  }, [nearby, radius])

  const plan: WeeklyPlan | undefined = plans[weekStart]

  const setProfile = useCallback((p: UserProfile) => setProfileState(p), [setProfileState])

  const generate = useCallback((ws: string = weekStart, p: UserProfile | null = profile) => {
    if (!p) return
    const prevWeek = Object.keys(plans).filter(k => k < ws).sort().pop()
    const next = generateWeek({
      profile: p, weekStart: ws, meals, workouts, previousPlan: prevWeek ? plans[prevWeek] : undefined,
      completedWorkouts, favoriteIds: favorites, coverageByMeal,
    })
    setPlans(prev => ({ ...prev, [ws]: next }))
    setShoppingStates(prev => ({ ...prev, [ws]: { removed: [], checked: [] } }))
  }, [weekStart, profile, plans, completedWorkouts, favorites, coverageByMeal, setPlans, setShoppingStates])

  const setSlotMeal = (date: string, slot: MealType, mealId: string) =>
    setPlans(prev => {
      const p = prev[weekStart]; if (!p) return prev
      return { ...prev, [weekStart]: { ...p, days: p.days.map(d => (d.date === date ? { ...d, [`${slot}Id`]: mealId } : d)) } }
    })
  const toggleFavorite = (id: string) => setFavorites(f => (f.includes(id) ? f.filter(x => x !== id) : [...f, id]))
  const toggleMealEaten = (date: string, slot: MealType, mealId: string) =>
    setCompletedMeals(c => (c.some(x => x.date === date && x.slot === slot) ? c.filter(x => !(x.date === date && x.slot === slot)) : [...c, { date, slot, mealId }]))
  const toggleWorkoutDone = (date: string, workoutId: string) =>
    setCompletedWorkouts(c => (c.some(x => x.date === date) ? c.filter(x => x.date !== date) : [...c, { date, workoutId }]))
  const addWeight = (date: string, weightLb: number) =>
    setWeightHistory(h => [...h.filter(x => x.date !== date), { date, weightLb }].sort((a, b) => a.date.localeCompare(b.date)))
  const removeWeight = (date: string) => setWeightHistory(h => h.filter(x => x.date !== date))

  const updateShopping = (fn: (s: ShoppingListState) => ShoppingListState) =>
    setShoppingStates(prev => ({ ...prev, [weekStart]: fn(prev[weekStart] ?? { removed: [], checked: [] }) }))
  const toggleIn = (arr: string[], k: string) => (arr.includes(k) ? arr.filter(x => x !== k) : [...arr, k])
  const shopping = {
    state: shoppingStates[weekStart] ?? { removed: [], checked: [] },
    toggleChecked: (k: string) => updateShopping(s => ({ ...s, checked: toggleIn(s.checked, k) })),
    remove: (k: string) => updateShopping(s => ({ ...s, removed: [...new Set([...s.removed, k])] })),
    restoreAll: () => updateShopping(s => ({ ...s, removed: [] })),
    restore: (keys: string[]) => updateShopping(s => ({ ...s, removed: s.removed.filter(k => !keys.includes(k)) })),
    toggleOwned: (ingredientId: string) => setOwned(o => toggleIn(o, ingredientId)),
  }
  const selectStore = (storeId: string) => setSelectedStores(s => ({ ...s, [weekStart]: storeId }))

  // ---- Location (explicit user actions only) ----
  const applyLocation = (mode: 'browser' | 'zip', location: UserLocation, zipCode?: string) =>
    setLocationPref({ mode, location, zipCode })
  const useBrowserLocation = async (): Promise<ActionResult> => {
    try { applyLocation('browser', await locationService.fromBrowser()); return { ok: true } }
    catch (e) { return { ok: false, message: e instanceof LocationError ? e.message : 'Could not get your location.' } }
  }
  const useZip = async (zip: string): Promise<ActionResult> => {
    try { applyLocation('zip', await locationService.fromZip(zip), zip.trim()); return { ok: true } }
    catch (e) { return { ok: false, message: e instanceof LocationError ? e.message : 'Could not use that ZIP code.' } }
  }
  const declineLocation = () => setLocationPref({ mode: 'declined' })
  const disableLocal = () => setLocationPref({ mode: 'disabled' })
  const removeLocationData = () => { setLocationPref({ mode: 'unset' }); setSelectedStores({}) }
  const resetAll = () => { storage.clearAll(); window.location.assign('/') }
  const retryNearby = () => setReloadTick(t => t + 1)

  return {
    profile, setProfile, locationPref, plans, plan, weekStart, setWeekStart, nearby, coverageByMeal, generate, setSlotMeal,
    favorites, toggleFavorite, completedMeals, toggleMealEaten, completedWorkouts, toggleWorkoutDone, weightHistory, addWeight, removeWeight,
    shopping, owned, selectedStores, selectStore, localOn, radius,
    useBrowserLocation, useZip, declineLocation, disableLocal, removeLocationData, retryNearby, resetAll,
  }
}

export type AppState = ReturnType<typeof useAppState>
const Ctx = createContext<AppState | null>(null)
export function AppProvider({ children }: { children: ReactNode }) {
  const state = useAppState()
  return <Ctx.Provider value={state}>{children}</Ctx.Provider>
}
export function useApp(): AppState {
  const v = useContext(Ctx)
  if (!v) throw new Error('useApp must be used inside AppProvider')
  return v
}

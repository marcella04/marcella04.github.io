import { useMemo } from 'react'
import { useApp } from '../state/AppContext'
import { meals } from '../data/meals'
import { generateShoppingList, weeklyRequirements } from '../engine/shoppingListGenerator'
import { familyOf } from '../engine/unitConversion'

export function useWeeklyBasket() {
  const { plan, shopping, owned } = useApp()
  return useMemo(() => {
    if (!plan) return { items: [], requirements: [], mealCount: 0 }
    const items = generateShoppingList(plan, meals)
    const { requirements, mealCount } = weeklyRequirements(plan, meals)
    const skip = new Set(shopping.state.removed)
    const requirementsToBuy = requirements.filter(r => !skip.has(`${r.ingredientId}|${familyOf(r.unit)}`) && !owned.includes(r.ingredientId))
    return { items, requirements: requirementsToBuy, mealCount }
  }, [plan, shopping.state.removed, owned])
}

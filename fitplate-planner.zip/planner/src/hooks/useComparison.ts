import { useMemo } from 'react'
import type { IngredientRequirement } from '../types'
import { compareStores, splitBasket } from '../engine/storeComparison'
import { useApp } from '../state/AppContext'

export function useComparison(requirements: IngredientRequirement[], servings: number) {
  const { nearby, radius } = useApp()
  return useMemo(() => {
    if (nearby.status !== 'ready' || !requirements.length) return null
    const input = { requirements, servings, stores: nearby.stores, prices: nearby.prices, radiusMiles: radius }
    const result = compareStores(input)
    return { input, result, split: splitBasket(input, result) }
  }, [nearby, radius, requirements, servings])
}

// DEMO STORES ONLY. Names are fictional, addresses are not real, and positions are
// generated as offsets from the user's search centre so the UI can be demonstrated anywhere.
export interface DemoStoreSpec {
  id: string; name: string; chain: string; dxMi: number; dyMi: number; supportedPricing: boolean
}
export const demoStoreSpecs: DemoStoreSpec[] = [
  { id: 'demo-market-a', name: 'Demo Market – Location A', chain: 'Demo Market', dxMi: 0.6, dyMi: 0.5, supportedPricing: true },
  { id: 'sample-grocer-a', name: 'Sample Grocer – Location A', chain: 'Sample Grocer', dxMi: -1.4, dyMi: 0.9, supportedPricing: true },
  { id: 'discount-foods-a', name: 'Demo Discount Foods – Location A', chain: 'Demo Discount Foods', dxMi: 2.2, dyMi: -1.8, supportedPricing: true },
  { id: 'co-op-a', name: 'Sample Co-op – Location A', chain: 'Sample Co-op', dxMi: 1.1, dyMi: 3.0, supportedPricing: false },
  { id: 'demo-market-b', name: 'Demo Market – Location B', chain: 'Demo Market', dxMi: -3.5, dyMi: -2.9, supportedPricing: true },
  { id: 'sample-grocer-b', name: 'Sample Grocer – Location B', chain: 'Sample Grocer', dxMi: 6.0, dyMi: 4.5, supportedPricing: true },
]
export const DEMO_ADDRESS = 'Demo location – not a real address'

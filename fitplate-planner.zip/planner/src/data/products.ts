import type { StoreProduct, Unit } from '../types'

// SAMPLE PRICING DATA — fictional, for demonstration only. Not live. No retrieval timestamps.
// [ingredientId, productName, brand, packageQuantity, packageUnit, price, salePrice?, estimated?]
type Base = [string, string, string | undefined, number, Unit, number, number?, boolean?]
const base: Base[] = [
  ['chicken-breast', 'Boneless skinless chicken breast', 'Store brand', 2.5, 'lb', 10.0],
  ['ground-turkey', 'Ground turkey 93% lean', 'Store brand', 1, 'lb', 5.49],
  ['salmon-fillet', 'Salmon fillet', undefined, 1, 'lb', 11.99, 9.99],
  ['shrimp', 'Peeled shrimp, frozen', 'Store brand', 1, 'lb', 9.99],
  ['tuna-can', 'Chunk light tuna', 'Store brand', 1, 'can', 1.29],
  ['rotisserie-chicken', 'Rotisserie chicken (meat portion)', undefined, 32, 'oz', 7.99],
  ['salad-kit', 'Chopped salad kit', 'Store brand', 1, 'package', 3.99],
  ['eggs', 'Large eggs', 'Store brand', 12, 'count', 3.49],
  ['tofu', 'Firm tofu', 'Store brand', 14, 'oz', 2.49],
  ['black-beans', 'Black beans, canned', 'Store brand', 1, 'can', 1.09],
  ['chickpeas', 'Chickpeas, canned', 'Store brand', 1, 'can', 1.19],
  ['lentils', 'Brown lentils, dry', 'Store brand', 16, 'oz', 1.79],
  ['brown-rice', 'Brown rice, 2 lb bag (≈12 dry cups)', 'Store brand', 12, 'cup', 2.99],
  ['quinoa', 'Quinoa, 12 oz bag (≈2 dry cups)', 'Store brand', 2, 'cup', 4.49],
  ['oats', 'Rolled oats, 18 oz (≈6 cups)', 'Store brand', 6, 'cup', 3.29],
  ['rice-pouch', 'Microwave brown rice pouches (2 ct)', 'Store brand', 2, 'count', 3.49],
  ['pasta', 'Pasta, 16 oz', 'Store brand', 16, 'oz', 1.69],
  ['broccoli', 'Broccoli crowns', undefined, 16, 'oz', 2.49],
  ['spinach', 'Baby spinach', undefined, 10, 'oz', 3.29],
  ['frozen-veg', 'Frozen stir-fry vegetables', 'Store brand', 16, 'oz', 2.19],
  ['romaine', 'Romaine hearts', undefined, 12, 'oz', 3.29],
  ['tomato', 'Roma tomato (each)', undefined, 1, 'count', 0.55],
  ['onion', 'Yellow onion (each)', undefined, 1, 'count', 0.89],
  ['garlic', 'Garlic head (≈10 cloves)', undefined, 10, 'count', 0.79],
  ['bell-pepper', 'Bell pepper (each)', undefined, 1, 'count', 1.25],
  ['cucumber', 'Cucumber (each)', undefined, 1, 'count', 0.79],
  ['carrot', 'Carrots, 1 lb bag (≈6)', undefined, 6, 'count', 1.49],
  ['avocado', 'Avocado (each)', undefined, 1, 'count', 1.49],
  ['lime', 'Lime (each)', undefined, 1, 'count', 0.5],
  ['banana', 'Banana (each)', undefined, 1, 'count', 0.3],
  ['sweet-potato', 'Sweet potatoes', undefined, 16, 'oz', 1.29],
  ['corn-tortilla', 'Corn tortillas, 30 ct', 'Store brand', 30, 'count', 2.79],
  ['wheat-wrap', 'Whole wheat wraps, 6 ct', 'Store brand', 6, 'count', 3.29],
  ['bread', 'Whole wheat bread (≈20 slices)', 'Store brand', 20, 'count', 3.19],
  ['cheese', 'Shredded cheese, 8 oz', 'Store brand', 8, 'oz', 3.29],
  ['greek-yogurt', 'Plain Greek yogurt, 32 oz', 'Store brand', 32, 'oz', 5.49],
  ['cottage-cheese', 'Cottage cheese, 16 oz', 'Store brand', 16, 'oz', 2.99],
  ['almonds', 'Whole almonds, 8 oz', 'Store brand', 8, 'oz', 5.99],
  ['peanut-butter', 'Peanut butter, 16 oz (≈32 tbsp)', 'Store brand', 32, 'tbsp', 2.79],
  ['hummus', 'Hummus, 10 oz', 'Store brand', 10, 'oz', 3.49],
  ['salsa', 'Salsa, 16 oz (≈2 cups)', 'Store brand', 2, 'cup', 2.49],
  ['marinara', 'Marinara sauce, 24 oz (≈3 cups)', 'Store brand', 3, 'cup', 2.79],
  ['diced-tomatoes', 'Diced tomatoes, canned', 'Store brand', 1, 'can', 1.19],
  ['corn-can', 'Sweet corn, canned', 'Store brand', 1, 'can', 0.99],
  ['soy-sauce', 'Soy sauce (≈20 tbsp)', 'Store brand', 20, 'tbsp', 2.49, undefined, true],
  ['olive-oil', 'Olive oil (≈34 tbsp)', 'Store brand', 34, 'tbsp', 6.99, undefined, true],
  ['curry-powder', 'Curry powder (≈30 tsp)', 'Store brand', 30, 'tsp', 3.29, undefined, true],
  // Recipe "spinach" can map to spring mix at one chain (demonstrates "mapped" matches)
  ['spring-mix', 'Spring mix greens, 5 oz', undefined, 5, 'oz', 3.49],
]

interface ChainPricing { mult: number; omit: string[]; outOfStock?: string[]; hasSpinach?: boolean }
const chains: Record<string, ChainPricing> = {
  'demo-market-a': { mult: 1.0, omit: ['spring-mix'] },
  'demo-market-b': { mult: 1.02, omit: ['spring-mix'] },
  'sample-grocer-a': { mult: 0.93, omit: ['tofu', 'quinoa', 'lentils', 'spring-mix'] },
  'sample-grocer-b': { mult: 0.91, omit: ['tofu', 'quinoa', 'lentils', 'spring-mix'] },
  'discount-foods-a': {
    mult: 0.82, omit: ['salmon-fillet', 'shrimp', 'avocado', 'hummus', 'quinoa', 'tofu', 'almonds', 'spinach', 'salad-kit', 'rotisserie-chicken'],
    outOfStock: ['cottage-cheese'],
  },
}
const cents = (n: number) => Math.round(n * 100) / 100

export const storeProducts: StoreProduct[] = Object.entries(chains).flatMap(([storeId, c]) =>
  base.filter(b => !c.omit.includes(b[0])).map(([ingredientId, productName, brand, qty, unit, price, sale, est]) => ({
    id: `${storeId}:${ingredientId}`, storeId, ingredientId, productName, brand,
    packageQuantity: qty, packageUnit: unit,
    regularPrice: cents(price * c.mult), salePrice: sale ? cents(sale * c.mult) : undefined,
    currency: 'USD', availability: c.outOfStock?.includes(ingredientId) ? 'out-of-stock' as const : 'in-stock' as const,
    priceType: est ? 'estimated' as const : 'sample' as const, dataSource: 'demo-sample-data',
  })),
)

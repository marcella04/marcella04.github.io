// Demo restaurant labels only. Not real locations or menus.
export const restaurants = [
  { id: 'demo-burrito', name: 'Fast-casual burrito shop (demo estimate)' },
  { id: 'demo-cafe', name: 'Neighborhood café (demo estimate)' },
  { id: 'demo-bowl', name: 'Asian-inspired bowl shop (demo estimate)' },
]

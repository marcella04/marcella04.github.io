import type { Equipment, Exercise, FitnessLevel, Workout, WorkoutCategory } from '../types'

const ex = (name: string, sets: number | undefined, reps: string | undefined, instructions: string, seconds?: number): Exercise =>
  ({ name, sets, reps, seconds, instructions })
const w = (id: string, name: string, difficulty: FitnessLevel, durationMin: number, equipment: Equipment[],
  category: WorkoutCategory, description: string, exercises: Exercise[]): Workout =>
  ({ id, name, difficulty, durationMin, equipment, category, description, exercises })

// Sample workouts for general fitness. Not medical or rehabilitation advice.
export const workouts: Workout[] = [
  w('walk-easy-20', 'Easy Walk', 'beginner', 20, ['none'], 'cardio', 'A comfortable-pace walk.',
    [ex('Easy walk', 1, undefined, 'Walk at a pace where you can hold a conversation.', 1200)]),
  w('walk-brisk-30', 'Brisk Walk', 'beginner', 30, ['none'], 'cardio', 'Steady brisk walking with short pace changes.',
    [ex('Warm-up walk', 1, undefined, 'Easy pace.', 300), ex('Brisk walk', 1, undefined, 'Slightly breathless pace.', 1200), ex('Cool-down walk', 1, undefined, 'Easy pace.', 300)]),
  w('intervals-30', 'Walk/Jog Intervals', 'intermediate', 30, ['none'], 'cardio', 'Alternating easy and faster efforts.',
    [ex('Warm-up', 1, undefined, 'Easy walk.', 300), ex('Intervals', 8, undefined, '1 min faster effort, 2 min easy.', 180), ex('Cool-down', 1, undefined, 'Easy walk.', 300)]),
  w('cardio-45', 'Steady Cardio', 'intermediate', 45, ['none'], 'cardio', 'Longer steady-state session: walk, jog, cycle or swim.',
    [ex('Steady cardio', 1, undefined, 'Moderate effort you could sustain for the full time.', 2700)]),
  w('full-body-beginner-30', 'Beginner Full Body', 'beginner', 30, ['none'], 'full-body', 'Bodyweight basics.',
    [ex('Chair squat', 3, '10', 'Sit back to a chair and stand up.'), ex('Incline push-up', 3, '8', 'Hands on a counter or wall.'),
     ex('Glute bridge', 3, '12', 'Drive through heels, squeeze at top.'), ex('Bird dog', 3, '8 per side', 'Move slowly, keep hips level.'), ex('Plank (knees ok)', 3, undefined, 'Keep a straight line.', 20)]),
  w('full-body-dumbbell-45', 'Dumbbell Full Body', 'intermediate', 45, ['dumbbells'], 'full-body', 'Compound movements with dumbbells.',
    [ex('Goblet squat', 3, '10', 'Hold one dumbbell at chest.'), ex('Dumbbell row', 3, '10 per side', 'Flat back, pull to hip.'),
     ex('Dumbbell press', 3, '10', 'Press overhead with control.'), ex('Romanian deadlift', 3, '10', 'Hinge at hips.'), ex('Plank', 3, undefined, 'Brace your core.', 40)]),
  w('full-body-bw-30', 'Bodyweight Circuit', 'intermediate', 30, ['none'], 'full-body', 'Circuit, 3 rounds.',
    [ex('Squat', 3, '15', 'Full range you control.'), ex('Push-up', 3, '10', 'Full or incline.'), ex('Reverse lunge', 3, '8 per side', 'Step back, lower, stand.'), ex('Dead bug', 3, '10', 'Press low back down.')]),
  w('full-body-gym-60', 'Gym Full Body', 'advanced', 60, ['gym'], 'full-body', 'Machines and free weights.',
    [ex('Back squat or leg press', 4, '8', 'Use a load you can control.'), ex('Bench press', 4, '8', 'Spotter or safeties recommended.'), ex('Seated row', 3, '10', 'Squeeze shoulder blades.'), ex('Shoulder press', 3, '10', 'Control the lowering.'), ex('Plank', 3, undefined, 'Brace.', 60)]),
  w('upper-bands-30', 'Upper Body with Bands', 'beginner', 30, ['bands'], 'upper', 'Resistance-band upper body.',
    [ex('Band row', 3, '12', 'Elbows back.'), ex('Band chest press', 3, '12', 'Anchor behind you.'), ex('Band shoulder press', 3, '10', 'Press overhead.'), ex('Band pull-apart', 3, '15', 'Arms straight.')]),
  w('upper-dumbbell-45', 'Upper Body Dumbbells', 'intermediate', 45, ['dumbbells'], 'upper', 'Push and pull.',
    [ex('Dumbbell bench or floor press', 4, '10', 'Control the lowering.'), ex('One-arm row', 4, '10 per side', 'Flat back.'), ex('Lateral raise', 3, '12', 'Light weight.'), ex('Biceps curl', 3, '12', 'No swinging.'), ex('Triceps extension', 3, '12', 'Elbows in.')]),
  w('upper-bw-30', 'Upper Body Bodyweight', 'beginner', 30, ['none'], 'upper', 'Push-ups and pulls without equipment.',
    [ex('Incline push-up', 3, '10', 'Hands elevated.'), ex('Pike push-up', 3, '6', 'Hips high.'), ex('Table row (if a sturdy table is available)', 3, '8', 'Keep body straight.'), ex('Shoulder taps', 3, '16', 'Minimise hip sway.')]),
  w('upper-gym-60', 'Upper Body Gym', 'advanced', 60, ['gym'], 'upper', 'Machine and cable upper-body session.',
    [ex('Incline press', 4, '8', 'Control.'), ex('Lat pulldown', 4, '10', 'Chest up.'), ex('Cable row', 3, '12', 'Squeeze.'), ex('Cable curl & pushdown', 3, '12', 'Superset.')]),
  w('lower-bw-30', 'Lower Body Bodyweight', 'beginner', 30, ['none'], 'lower', 'Legs and glutes.',
    [ex('Squat', 3, '12', 'Heels down.'), ex('Reverse lunge', 3, '8 per side', 'Step back.'), ex('Glute bridge', 3, '15', 'Pause at top.'), ex('Calf raise', 3, '15', 'Slow tempo.')]),
  w('lower-dumbbell-45', 'Lower Body Dumbbells', 'intermediate', 45, ['dumbbells'], 'lower', 'Strength for legs and glutes.',
    [ex('Goblet squat', 4, '10', 'Chest up.'), ex('Romanian deadlift', 4, '10', 'Hinge.'), ex('Walking lunge', 3, '10 per side', 'Long step.'), ex('Hip thrust', 3, '12', 'Shoulders on a bench or sofa.')]),
  w('lower-gym-60', 'Lower Body Gym', 'advanced', 60, ['gym'], 'lower', 'Leg day.',
    [ex('Back squat', 4, '6', 'Use safeties.'), ex('Leg press', 3, '10', 'Full range you control.'), ex('Leg curl', 3, '12', 'Slow.'), ex('Calf raise', 4, '12', 'Pause at top.')]),
  w('mobility-20', 'Mobility Flow', 'beginner', 20, ['none'], 'mobility', 'Gentle full-body mobility for recovery.',
    [ex('Cat-cow', 2, '10', 'Move with your breath.'), ex('World’s greatest stretch', 2, '5 per side', 'Slow.'), ex('Hip flexor stretch', 2, undefined, 'Hold.', 30), ex('Hamstring stretch', 2, undefined, 'Gentle.', 30), ex('Child’s pose', 1, undefined, 'Breathe slowly.', 60)]),
  w('mobility-30', 'Longer Mobility & Stretch', 'intermediate', 30, ['none'], 'mobility', 'Extended mobility session.',
    [ex('Joint circles', 1, '10 each', 'Neck to ankles.'), ex('Deep squat hold', 3, undefined, 'Hold with support if needed.', 30), ex('Thoracic rotation', 2, '8 per side', 'Slow.'), ex('Pigeon stretch', 2, undefined, 'Stop if painful.', 45)]),
  w('rest-day', 'Rest Day', 'beginner', 0, ['none'], 'rest', 'Rest is part of the plan. Optional gentle walk or stretching if it feels good.', []),
]
export const workoutById: Record<string, Workout> = Object.fromEntries(workouts.map(x => [x.id, x]))

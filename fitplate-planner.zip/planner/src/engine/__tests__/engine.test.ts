import { describe, expect, it } from 'vitest'
import { haversineMiles } from '../distanceCalculator'
import { convert } from '../unitConversion'
import { calcBmr, calcTargets, isMealSafe, validateProfile } from '../nutritionCalculator'
import { matchRequirement } from '../productMatching'
import { compareStores, splitBasket } from '../storeComparison'
import { generateWeek } from '../weeklyPlanner'
import { generateShoppingList } from '../shoppingListGenerator'
import { swapCandidates, defaultContext } from '../mealRecommendation'
import { meals } from '../../data/meals'
import { workouts } from '../../data/workouts'
import { storeProducts } from '../../data/products'
import { MockStoreProvider } from '../../services/stores/MockStoreProvider'
import { MockPricingProvider } from '../../services/pricing/MockPricingProvider'
import { ZipCodeLocationProvider } from '../../services/location/ZipCodeLocationProvider'
import type { GroceryPrice, UserProfile } from '../../types'

const profile: UserProfile = {
  onboarded: true, age: 35, sex: 'female', heightIn: 66, weightLb: 190, goalWeightLb: 160, activity: 'light', diet: 'omnivore',
  allergies: [], dislikedFoods: '', dailyFoodBudget: 20, weeklyGroceryBudget: 120, maxPricePerMeal: 8, cooking: 'minimal',
  maxPrepMinutes: 30, fitness: 'beginner', equipment: ['none'], workoutMinutes: 30, workoutDaysPerWeek: 3, storeRadiusMiles: 5, storePriority: 'best-value',
}

describe('distance', () => {
  it('matches known coordinates (NYC → LA ≈ 2445 mi)', () => {
    const d = haversineMiles({ latitude: 40.7128, longitude: -74.006 }, { latitude: 34.0522, longitude: -118.2437 })
    expect(d).toBeGreaterThan(2430); expect(d).toBeLessThan(2460)
  })
  it('is zero for identical points', () => expect(haversineMiles({ latitude: 1, longitude: 1 }, { latitude: 1, longitude: 1 })).toBe(0))
})

describe('units', () => {
  it('converts compatible weights', () => expect(convert(0.4, 'lb', 'oz')).toBeCloseTo(6.4))
  it('refuses volume↔weight without density data', () => expect(convert(1, 'cup', 'oz', 'chicken-breast')).toBeNull())
  it('allows volume→weight with ingredient data', () => expect(convert(1, 'cup', 'oz', 'olive-oil')).toBeCloseTo(7.6))
  it('never converts discrete units across kinds', () => { expect(convert(1, 'can', 'count')).toBeNull(); expect(convert(1, 'package', 'can')).toBeNull() })
})

describe('nutrition', () => {
  it('Mifflin-St Jeor reference (female, 190 lb, 66 in, 35y)', () => expect(Math.round(calcBmr(profile))).toBe(1574))
  it('applies a capped deficit above the safety floor', () => {
    const t = calcTargets(profile)
    expect(t.deficit).toBeLessThanOrEqual(500); expect(t.dailyTarget).toBeGreaterThanOrEqual(1200)
  })
  it('uses maintenance when goal ≥ current', () => expect(calcTargets({ ...profile, goalWeightLb: 190 }).deficit).toBeLessThanOrEqual(5))
  it('rejects invalid input', () => expect(validateProfile({ ...profile, age: 5 }).errors.length).toBeGreaterThan(0))
})

describe('allergy safety', () => {
  it('excludes every meal containing a flagged allergen, including via ingredient tags', () => {
    const p = { ...profile, allergies: ['peanut', 'shellfish', 'dairy'] as UserProfile['allergies'] }
    const safe = meals.filter(m => isMealSafe(m, p))
    expect(safe.some(m => m.id === 'peanut-noodle-bowl' || m.id === 'shrimp-pasta-marinara' || m.id === 'greek-yogurt-parfait')).toBe(false)
    expect(safe.length).toBeGreaterThan(0)
  })
  it('weekly plans and swaps never contain allergens or violate diet', () => {
    const p = { ...profile, allergies: ['egg', 'fish'] as UserProfile['allergies'], diet: 'vegetarian' as const, maxPricePerMeal: 15 }
    const plan = generateWeek({ profile: p, weekStart: '2026-10-26', meals, workouts })
    const ids = plan.days.flatMap(d => [d.lunchId, d.dinnerId]).filter(Boolean)
    expect(ids.length).toBeGreaterThan(0)
    ids.forEach(id => expect(isMealSafe(meals.find(m => m.id === id)!, p)).toBe(true))
    const mode = ['cheapest', 'high-protein', 'faster', 'different', 'vegetarian', 'restaurant', 'grocery-prepared'] as const
    mode.forEach(m => swapCandidates(meals, p, 'lunch', undefined, m, defaultContext(p)).forEach(s => expect(isMealSafe(s.meal, p)).toBe(true)))
  })
})

const price = (o: Partial<GroceryPrice>): GroceryPrice => ({
  ingredientId: 'chicken-breast', productId: 'x', productName: 'Boneless skinless chicken breast', storeId: 's1', regularPrice: 10, currency: 'USD',
  packageQuantity: 2.5, packageUnit: 'lb', availability: 'in-stock', priceType: 'sample', source: 'test', ...o,
})
describe('matching & pricing', () => {
  const req = { ingredientId: 'chicken-breast', name: 'Chicken breast', quantity: 0.4, unit: 'lb' as const }
  it('exact / mapped / uncertain / unmatched', () => {
    expect(matchRequirement(req, [price({})]).confidence).toBe('exact')
    expect(matchRequirement({ ...req, ingredientId: 'spinach', name: 'Baby spinach' }, [price({ ingredientId: 'spring-mix', productName: 'Spring mix' })]).confidence).toBe('mapped')
    expect(matchRequirement(req, [price({ ingredientId: 'other' })]).confidence).toBe('uncertain')
    expect(matchRequirement(req, [price({ ingredientId: 'other', productName: 'Bananas' })]).confidence).toBe('unmatched')
  })
  const store = { id: 's1', name: 'S', chain: 'C', address: '', latitude: 0, longitude: 0, distanceMiles: 1, supportedPricing: true, dataSource: 'demo' as const }
  it('usage cost vs package cost: 0.4 lb of a $10 / 2.5 lb pack = $1.60 usage, $10 checkout', () => {
    const r = compareStores({ requirements: [req], servings: 1, stores: [store], prices: [price({})], radiusMiles: 5 }).rows[0]
    expect(r.estimatedUsageCost).toBeCloseTo(1.6); expect(r.totalCheckoutCost).toBe(10); expect(r.coveragePercent).toBe(100)
  })
  it('never treats a missing price as zero and reports coverage', () => {
    const reqs = [req, { ingredientId: 'tofu', name: 'Tofu', quantity: 7, unit: 'oz' as const }]
    const r = compareStores({ requirements: reqs, servings: 1, stores: [store], prices: [price({})], radiusMiles: 5 })
    expect(r.rows[0].coveragePercent).toBe(50); expect(r.rows[0].missingIngredients[0].ingredientId).toBe('tofu')
    expect(r.confident).toBe(false); expect(r.headline).toMatch(/available data/)
  })
  it('flags incompatible units instead of guessing', () => {
    const r = compareStores({ requirements: [{ ...req, unit: 'cup' }], servings: 1, stores: [store], prices: [price({})], radiusMiles: 5 })
    expect(r.rows[0].missingIngredients[0].reason).toBe('unit-incompatible')
  })
})

describe('sample data integrity', () => {
  it('no sample product is labelled live and none carry fabricated timestamps', () => {
    expect(storeProducts.every(p => p.priceType !== 'live' && p.retrievedAt === undefined)).toBe(true)
  })
  it('every recipe ingredient is in the catalog', async () => {
    const { ingredientById } = await import('../../data/ingredients')
    meals.flatMap(m => m.ingredients).forEach(i => expect(ingredientById[i.ingredientId], i.ingredientId).toBeDefined())
  })
})

describe('end-to-end with mock providers', () => {
  it('compares a weekly basket and generates a consolidated shopping list', async () => {
    const stores = await new MockStoreProvider().findNearby({ latitude: 40, longitude: -100, radiusMiles: 5 })
    expect(stores.length).toBeGreaterThan(0); expect(stores.every(s => s.dataSource === 'demo' && s.distanceMiles <= 5)).toBe(true)
    const prices = await new MockPricingProvider().getPrices({ stores, ingredientIds: [] })
    const plan = generateWeek({ profile, weekStart: '2026-10-26', meals, workouts })
    const list = generateShoppingList(plan, meals)
    expect(new Set(list.map(i => i.key)).size).toBe(list.length)
    const { weeklyRequirements } = await import('../shoppingListGenerator')
    const { requirements, mealCount } = weeklyRequirements(plan, meals)
    const input = { requirements, servings: mealCount, stores, prices, radiusMiles: 5 }
    const cmp = compareStores(input)
    expect(cmp.best).toBeDefined(); expect(cmp.rows.every(r => r.store.supportedPricing)).toBe(true)
    expect(splitBasket(input, cmp).message.length).toBeGreaterThan(0)
  })
  it('ZIP provider validates', async () => {
    const z = new ZipCodeLocationProvider()
    await expect(z.getLocation({ zipCode: '12' })).rejects.toMatchObject({ code: 'invalid-zip' })
    await expect(z.getLocation({})).rejects.toMatchObject({ code: 'missing-zip' })
    expect((await z.getLocation({ zipCode: '90210' })).source).toBe('zip-demo')
  })
})

import type { Unit } from '../types'

type Family = 'weight' | 'volume' | 'count' | 'package' | 'can'
const FAMILY: Record<Unit, Family> = {
  oz: 'weight', lb: 'weight', g: 'weight', kg: 'weight',
  tsp: 'volume', tbsp: 'volume', cup: 'volume', ml: 'volume', l: 'volume',
  count: 'count', package: 'package', can: 'can',
}
// Factor to family base unit (oz for weight, tsp for volume)
const TO_BASE: Record<Unit, number> = {
  oz: 1, lb: 16, g: 0.035274, kg: 35.274,
  tsp: 1, tbsp: 3, cup: 48, ml: 0.202884, l: 202.884,
  count: 1, package: 1, can: 1,
}
/** Ingredient-specific volume→weight data (ounces per cup). Only listed ingredients may cross families. */
export const densityOzPerCup: Record<string, number> = { 'olive-oil': 7.6, 'soy-sauce': 9, 'peanut-butter': 9.2 }

export const familyOf = (u: Unit): Family => FAMILY[u]
export const areCompatible = (a: Unit, b: Unit) => FAMILY[a] === FAMILY[b]

/** Returns null when conversion isn't meaningful or data is missing. Never guesses. */
export function convert(qty: number, from: Unit, to: Unit, ingredientId?: string): number | null {
  if (!Number.isFinite(qty)) return null
  if (from === to) return qty
  if (FAMILY[from] === FAMILY[to]) return (qty * TO_BASE[from]) / TO_BASE[to]
  const d = ingredientId ? densityOzPerCup[ingredientId] : undefined
  if (!d) return null
  if (FAMILY[from] === 'volume' && FAMILY[to] === 'weight') return (((qty * TO_BASE[from]) / 48) * d) / TO_BASE[to]
  if (FAMILY[from] === 'weight' && FAMILY[to] === 'volume') return (((qty * TO_BASE[from]) / d) * 48) / TO_BASE[to]
  return null
}

/** Pick a friendly display unit for a quantity expressed in the family's base unit. */
export function friendlyUnit(qtyInBase: number, family: Family): { quantity: number; unit: Unit } {
  const round = (n: number) => Math.round(n * 100) / 100
  if (family === 'weight') return qtyInBase >= 16 ? { quantity: round(qtyInBase / 16), unit: 'lb' } : { quantity: round(qtyInBase), unit: 'oz' }
  if (family === 'volume') {
    if (qtyInBase >= 48) return { quantity: round(qtyInBase / 48), unit: 'cup' }
    if (qtyInBase >= 3) return { quantity: round(qtyInBase / 3), unit: 'tbsp' }
    return { quantity: round(qtyInBase), unit: 'tsp' }
  }
  return { quantity: round(qtyInBase), unit: family }
}
export const toBase = (qty: number, unit: Unit) => qty * TO_BASE[unit]

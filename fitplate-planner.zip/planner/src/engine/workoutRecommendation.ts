import type { CompletedWorkout, Equipment, UserProfile, Workout, WorkoutCategory } from '../types'

const LEVEL = { beginner: 0, intermediate: 1, advanced: 2 } as const
// Weekly category pattern, Monday→Sunday, by active days per week. Hard days are never back-to-back for the same muscle group.
const PATTERNS: Record<number, WorkoutCategory[]> = {
  2: ['full-body', 'rest', 'rest', 'cardio', 'rest', 'mobility', 'rest'],
  3: ['full-body', 'rest', 'cardio', 'rest', 'full-body', 'mobility', 'rest'],
  4: ['upper', 'cardio', 'lower', 'rest', 'full-body', 'mobility', 'rest'],
  5: ['upper', 'lower', 'cardio', 'upper', 'lower', 'mobility', 'rest'],
  6: ['upper', 'lower', 'cardio', 'upper', 'lower', 'cardio', 'mobility'],
}
export const feasible = (w: Workout, owned: Equipment[]) => w.equipment.every(e => e === 'none' || owned.includes(e))

export function pickWorkout(all: Workout[], cat: WorkoutCategory, p: UserProfile, recentIds: string[], usedIds: string[]): Workout | undefined {
  const rest = all.find(w => w.category === 'rest')
  if (cat === 'rest') return rest
  const pool = all.filter(w => w.category === cat && feasible(w, p.equipment) && LEVEL[w.difficulty] <= LEVEL[p.fitness])
  const score = (w: Workout) =>
    -Math.abs(w.durationMin - p.workoutMinutes) / 15 + (LEVEL[w.difficulty] === LEVEL[p.fitness] ? 1 : 0)
    - (recentIds.includes(w.id) ? 1.5 : 0) - (usedIds.includes(w.id) ? 1 : 0)
  return [...pool].sort((a, b) => score(b) - score(a) || a.id.localeCompare(b.id))[0]
}

/** Plans a balanced week from fitness level, equipment, duration, recovery and history — never from food intake. */
export function planWorkouts(all: Workout[], p: UserProfile, completed: CompletedWorkout[], weekStart: string): { ids: (string | undefined)[]; warnings: string[] } {
  const days = Math.min(6, Math.max(2, p.fitness === 'beginner' ? Math.min(5, p.workoutDaysPerWeek) : p.workoutDaysPerWeek))
  const pattern = [...PATTERNS[days]]
  const recent = completed.filter(c => c.date < weekStart).sort((a, b) => b.date.localeCompare(a.date))
  const recentIds = recent.slice(0, 6).map(c => c.workoutId)
  // Recovery: if the last completed session was upper/lower, avoid the same on Monday
  const last = all.find(w => w.id === recent[0]?.workoutId)
  if (last && pattern[0] === last.category && (last.category === 'upper' || last.category === 'lower') && recent[0].date >= prevDay(weekStart)) {
    pattern[0] = last.category === 'upper' ? 'lower' : 'upper'
  }
  const used: string[] = [], warnings: string[] = []
  const ids = pattern.map(cat => {
    const w = pickWorkout(all, cat, p, recentIds, used)
    if (!w) { if (cat !== 'rest') warnings.push(`No ${cat.replace('-', ' ')} workout matches your equipment and level; that day is a rest day.`); return all.find(x => x.category === 'rest')?.id }
    used.push(w.id)
    return w.id
  })
  return { ids, warnings: [...new Set(warnings)] }
}
function prevDay(s: string) { const [y, m, d] = s.split('-').map(Number); const x = new Date(y, m - 1, d - 1); return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}` }

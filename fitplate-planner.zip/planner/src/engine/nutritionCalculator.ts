import type { ActivityLevel, Allergen, DietPref, Meal, MealType, UserProfile } from '../types'
import { calorieBounds, mealShare } from '../config/recommendationWeights'
import { ingredientById } from '../data/ingredients'

const LB_TO_KG = 0.45359237, IN_TO_CM = 2.54
const ACTIVITY: Record<ActivityLevel, number> = { sedentary: 1.2, light: 1.375, moderate: 1.55, active: 1.725 }
const MIN_CALORIES = { female: 1200, male: 1500 } as const

/** Mifflin-St Jeor BMR (kcal/day). */
export function calcBmr(p: Pick<UserProfile, 'sex' | 'weightLb' | 'heightIn' | 'age'>): number {
  return 10 * p.weightLb * LB_TO_KG + 6.25 * p.heightIn * IN_TO_CM - 5 * p.age + (p.sex === 'male' ? 5 : -161)
}
export const calcTdee = (p: UserProfile) => calcBmr(p) * ACTIVITY[p.activity]
export const bmi = (weightLb: number, heightIn: number) => (weightLb * 703) / (heightIn * heightIn)

export interface ProfileCheck { errors: string[]; warnings: string[] }
export function validateProfile(p: UserProfile): ProfileCheck {
  const errors: string[] = [], warnings: string[] = []
  if (!(p.age >= 13 && p.age <= 100)) errors.push('Age must be between 13 and 100.')
  if (!(p.heightIn >= 48 && p.heightIn <= 90)) errors.push('Height must be between 48 and 90 inches.')
  if (!(p.weightLb >= 70 && p.weightLb <= 700)) errors.push('Current weight must be between 70 and 700 lb.')
  if (!(p.goalWeightLb >= 70 && p.goalWeightLb <= 700)) errors.push('Goal weight must be between 70 and 700 lb.')
  if (p.dailyFoodBudget <= 0 || p.weeklyGroceryBudget <= 0 || p.maxPricePerMeal <= 0) errors.push('Budgets must be greater than zero.')
  if (p.storeRadiusMiles <= 0) errors.push('Store radius must be greater than zero.')
  if (errors.length) return { errors, warnings }
  if (p.age < 18) warnings.push('This planner is designed for adults. Weight-loss targets are disabled; talk to a doctor about nutrition for teens.')
  if (bmi(p.weightLb, p.heightIn) < 18.5) warnings.push('Your current weight is in a range where weight loss is not suggested. Calorie targets are set to maintenance.')
  else if (bmi(p.goalWeightLb, p.heightIn) < 18.5) warnings.push('Your goal weight is in a range where weight loss is not suggested. Calorie targets are set to maintenance.')
  return { errors, warnings }
}

export interface CalorieTargets {
  bmr: number; tdee: number; dailyTarget: number; deficit: number; lunch: number; dinner: number
  dailyProtein: number; note: string
}
/** Estimates only. Deficit is capped at the smaller of 20% of TDEE or 500 kcal and never goes below a safety floor. */
export function calcTargets(p: UserProfile): CalorieTargets {
  const bmr = calcBmr(p), tdee = bmr * ACTIVITY[p.activity]
  const maintain = p.age < 18 || p.goalWeightLb >= p.weightLb || bmi(p.weightLb, p.heightIn) < 18.5 || bmi(p.goalWeightLb, p.heightIn) < 18.5
  const rawDeficit = maintain ? 0 : Math.min(500, tdee * 0.2)
  const floor = MIN_CALORIES[p.sex]
  const target = Math.round(Math.max(tdee - rawDeficit, Math.min(tdee, floor)) / 10) * 10
  const dailyProtein = Math.round(Math.min(160, Math.max(60, p.goalWeightLb * 0.7)))
  return {
    bmr: Math.round(bmr), tdee: Math.round(tdee), dailyTarget: target, deficit: Math.round(tdee - target),
    lunch: Math.round(target * mealShare.lunch), dinner: Math.round(target * mealShare.dinner),
    dailyProtein, note: maintain ? 'Maintenance estimate (no deficit applied).' : 'Estimate with a modest, capped deficit.',
  }
}
export const mealCalorieTarget = (t: CalorieTargets, slot: MealType) => (slot === 'lunch' ? t.lunch : t.dinner)
export const mealProteinTarget = (t: CalorieTargets, slot: MealType) => Math.round(t.dailyProtein * mealShare[slot])

// ---- Eligibility / safety ----
const DIET_RANK: Record<DietPref, number> = { vegan: 0, vegetarian: 1, pescatarian: 2, omnivore: 3 }
/** Union of declared allergens and allergen tags from structured ingredient data (never text matching). */
export function mealAllergens(meal: Meal): Allergen[] {
  const s = new Set<Allergen>(meal.allergens)
  for (const i of meal.ingredients) ingredientById[i.ingredientId]?.allergenTags.forEach(a => s.add(a))
  return [...s]
}
export const violatesAllergy = (meal: Meal, allergies: Allergen[]) => mealAllergens(meal).some(a => allergies.includes(a))
export const mealDietLevel = (meal: Meal) => Math.min(...meal.dietTags.map(t => DIET_RANK[t]))
export const matchesDiet = (meal: Meal, diet: DietPref) => mealDietLevel(meal) <= DIET_RANK[diet]
export const dietRank = (d: DietPref) => DIET_RANK[d]

export function mentionsDisliked(meal: Meal, disliked: string): boolean {
  const terms = disliked.toLowerCase().split(/[,;\n]/).map(s => s.trim()).filter(s => s.length > 1)
  if (!terms.length) return false
  const hay = [meal.name, ...meal.ingredients.flatMap(i => [i.name, ...(ingredientById[i.ingredientId]?.aliases ?? [])])].join(' | ').toLowerCase()
  return terms.some(t => hay.includes(t))
}
/** Hard safety gate. Never relaxed by any planner or swap mode. */
export const isMealSafe = (meal: Meal, p: UserProfile) =>
  !violatesAllergy(meal, p.allergies) && matchesDiet(meal, p.diet) && !mentionsDisliked(meal, p.dislikedFoods)
export const calorieEligible = (meal: Meal, target: number) =>
  meal.calories >= target * calorieBounds.min && meal.calories <= target * calorieBounds.max

import type { GroceryPrice, IngredientRequirement } from '../types'
import { ingredientById } from '../data/ingredients'

export type MatchConfidence = 'exact' | 'mapped' | 'uncertain' | 'unmatched'
export interface ProductMatch { requirement: IngredientRequirement; price?: GroceryPrice; confidence: MatchConfidence }

/** Explicit, curated substitutions (requirement ingredient → acceptable product ingredient IDs). */
export const MAPPED_EQUIVALENTS: Record<string, string[]> = { spinach: ['spring-mix'] }

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim()
export const effectivePrice = (p: GroceryPrice) => p.salePrice ?? p.regularPrice

/**
 * Matches a recipe requirement to a store product.
 *  exact: same ingredient ID. mapped: curated equivalent. uncertain: only alias/name text overlap.
 *  Text matching is for price lookup only — allergy safety uses structured ingredient tags.
 */
export function matchRequirement(req: IngredientRequirement, prices: GroceryPrice[]): ProductMatch {
  const exact = prices.find(p => p.ingredientId === req.ingredientId)
  if (exact) return { requirement: req, price: exact, confidence: 'exact' }
  for (const eq of MAPPED_EQUIVALENTS[req.ingredientId] ?? []) {
    const hit = prices.find(p => p.ingredientId === eq)
    if (hit) return { requirement: req, price: hit, confidence: 'mapped' }
  }
  const ing = ingredientById[req.ingredientId]
  const names = [ing?.name ?? req.name, ...(ing?.aliases ?? [])].map(norm).filter(Boolean)
  const textHit = prices.find(p => names.some(n => norm(p.productName).includes(n)))
  if (textHit) return { requirement: req, price: textHit, confidence: 'uncertain' }
  return { requirement: req, confidence: 'unmatched' }
}

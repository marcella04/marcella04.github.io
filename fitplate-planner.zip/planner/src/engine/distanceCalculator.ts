import type { Coords } from '../types'
const EARTH_RADIUS_MILES = 3958.8
const rad = (d: number) => (d * Math.PI) / 180
/** Approximate straight-line (great-circle) distance in miles. NOT driving distance or travel time. */
export function haversineMiles(a: Coords, b: Coords): number {
  const dLat = rad(b.latitude - a.latitude), dLon = rad(b.longitude - a.longitude)
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.latitude)) * Math.cos(rad(b.latitude)) * Math.sin(dLon / 2) ** 2
  return 2 * EARTH_RADIUS_MILES * Math.asin(Math.min(1, Math.sqrt(h)))
}
export const formatApproxMiles = (m: number) => `≈ ${m.toFixed(1)} mi (straight-line)`

import type { IngredientRequirement, Meal, ShoppingItem, Unit, WeeklyPlan } from '../types'
import { ingredientById } from '../data/ingredients'
import { familyOf, friendlyUnit, toBase } from './unitConversion'

/** Scaled requirement for ONE serving of each planned meal (recipe quantity ÷ servings). */
export function weeklyRequirements(plan: WeeklyPlan, meals: Meal[]): { requirements: IngredientRequirement[]; mealCount: number } {
  const acc = new Map<string, IngredientRequirement>()
  let mealCount = 0
  for (const d of plan.days) for (const id of [d.lunchId, d.dinnerId]) {
    const meal = meals.find(m => m.id === id); if (!meal) continue
    mealCount++
    for (const ing of meal.ingredients) {
      const fam = familyOf(ing.unit)
      const key = `${ing.ingredientId}|${fam}`
      const baseQty = toBase(ing.quantity / meal.servings, ing.unit)
      const cur = acc.get(key)
      const baseUnit: Unit = fam === 'weight' ? 'oz' : fam === 'volume' ? 'tsp' : (fam as Unit)
      acc.set(key, { ingredientId: ing.ingredientId, name: ing.name, unit: baseUnit, quantity: (cur?.quantity ?? 0) + baseQty })
    }
  }
  return { requirements: [...acc.values()], mealCount }
}

/** Compatible units are merged; incompatible families stay as separate lines. */
export function generateShoppingList(plan: WeeklyPlan, meals: Meal[]): ShoppingItem[] {
  return weeklyRequirements(plan, meals).requirements.map(r => {
    const cat = ingredientById[r.ingredientId]
    const { quantity, unit } = friendlyUnit(r.quantity, familyOf(r.unit))
    return { key: `${r.ingredientId}|${familyOf(r.unit)}`, ingredientId: r.ingredientId, name: r.name, quantity, unit, category: cat?.category ?? 'Other', pantry: !!cat?.pantryStaple }
  }).sort((a, b) => Number(a.pantry) - Number(b.pantry) || a.category.localeCompare(b.category) || a.name.localeCompare(b.name))
}

import type { Meal, MealType, UserProfile, WeeklyPlan, Workout, CompletedWorkout } from '../types'
import { addDays } from '../utils/dates'
import { calcTargets } from './nutritionCalculator'
import { rankMeals, type RankContext } from './mealRecommendation'
import { planWorkouts } from './workoutRecommendation'

export interface PlanInput {
  profile: UserProfile; weekStart: string; meals: Meal[]; workouts: Workout[]
  previousPlan?: WeeklyPlan; completedWorkouts?: CompletedWorkout[]
  favoriteIds?: string[]; coverageByMeal?: Record<string, number>
}
type Relax = NonNullable<RankContext['relax']>
const RELAX_STEPS: { relax: Relax; warning: string }[] = [
  { relax: {}, warning: '' },
  { relax: { budget: true }, warning: 'No complete plan could satisfy your per-meal budget with the other settings. Some meals exceed it; the closest available plan is shown.' },
  { relax: { budget: true, prep: true }, warning: 'Some meals exceed your preparation-time limit because no compatible option fit.' },
  { relax: { budget: true, prep: true, cooking: true }, warning: 'Some meals do not match your cooking preference because no compatible option fit.' },
]

export function generateWeek(input: PlanInput): WeeklyPlan {
  const { profile: p, meals, weekStart } = input
  const targets = calcTargets(p)
  const warnings: string[] = []
  const used: string[] = []
  const prevIds = input.previousPlan?.days.flatMap(d => [d.lunchId, d.dinnerId]).filter(Boolean) as string[] | undefined
  const days = Array.from({ length: 7 }, (_, i) => ({ date: addDays(weekStart, i) } as WeeklyPlan['days'][number]))
  const pushWarn = (w: string) => { if (w && !warnings.includes(w)) warnings.push(w) }
  let repeats = false

  const pick = (slot: MealType, sameDayId?: string): string | undefined => {
    for (const step of RELAX_STEPS) {
      const ctx: RankContext = { targets, relax: step.relax, favoriteIds: input.favoriteIds, coverageByMeal: input.coverageByMeal, recentMealIds: [...(prevIds ?? []), ...used] }
      const ranked = rankMeals(meals, p, slot, ctx).filter(s => s.meal.id !== sameDayId)
      if (!ranked.length) continue
      const fresh = ranked.find(s => !used.includes(s.meal.id))
      if (fresh) { pushWarn(step.warning); return fresh.meal.id }
      // only repeats remain at this relaxation level — try looser levels for a fresh meal first
      const looser = RELAX_STEPS.slice(RELAX_STEPS.indexOf(step) + 1).some(s2 =>
        rankMeals(meals, p, slot, { ...ctx, relax: s2.relax }).some(x => !used.includes(x.meal.id) && x.meal.id !== sameDayId))
      if (looser) continue
      repeats = true; pushWarn(step.warning)
      return ranked.sort((a, b) => used.lastIndexOf(a.meal.id) - used.lastIndexOf(b.meal.id) || b.score - a.score)[0].meal.id
    }
    return undefined
  }
  for (const d of days) {
    d.lunchId = pick('lunch'); if (d.lunchId) used.push(d.lunchId)
    d.dinnerId = pick('dinner', d.lunchId); if (d.dinnerId) used.push(d.dinnerId)
    if (!d.lunchId || !d.dinnerId) pushWarn('Some meal slots could not be filled: your allergies, diet and calorie settings leave no compatible meal in the sample database.')
  }
  if (repeats) pushWarn('There were not enough compatible meals to avoid repeats; some meals repeat during the week.')

  // Weekly grocery budget: swap the most expensive meals for cheaper compatible ones where possible
  const costOf = (id?: string) => meals.find(m => m.id === id)?.estimatedCostPerServing ?? 0
  const total = () => days.reduce((s, d) => s + costOf(d.lunchId) + costOf(d.dinnerId), 0)
  for (let guard = 0; guard < 14 && total() > p.weeklyGroceryBudget; guard++) {
    const slots = days.flatMap(d => (['lunch', 'dinner'] as const).map(s => ({ d, s, id: d[`${s}Id` as const] })))
      .filter(x => x.id).sort((a, b) => costOf(b.id) - costOf(a.id))
    let swapped = false
    for (const x of slots) {
      const alt = rankMeals(meals, p, x.s, { targets, relax: { budget: true, prep: true, cooking: true } })
        .filter(c => c.meal.estimatedCostPerServing < costOf(x.id) && !used.filter(u => u !== x.id).includes(c.meal.id) && !days.some(d => d.lunchId === c.meal.id || d.dinnerId === c.meal.id))
        .sort((a, b) => a.meal.estimatedCostPerServing - b.meal.estimatedCostPerServing)[0]
      if (alt) { x.d[`${x.s}Id` as const] = alt.meal.id; used.push(alt.meal.id); swapped = true; break }
    }
    if (!swapped) break
  }
  if (total() > p.weeklyGroceryBudget) pushWarn(`The planned meals are estimated at $${total().toFixed(2)}, above your $${p.weeklyGroceryBudget.toFixed(2)} weekly grocery budget. This is the closest available plan.`)

  const w = planWorkouts(input.workouts, p, input.completedWorkouts ?? [], weekStart)
  days.forEach((d, i) => { d.workoutId = w.ids[i] })
  w.warnings.forEach(pushWarn)
  return { weekStart, days, warnings, generatedAt: new Date().toISOString() }
}

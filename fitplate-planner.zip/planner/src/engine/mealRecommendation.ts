import type { Meal, MealType, UserProfile } from '../types'
import { recommendationWeights as W } from '../config/recommendationWeights'
import {
  calcTargets, calorieEligible, dietRank, isMealSafe, mealCalorieTarget, mealProteinTarget, mealDietLevel, type CalorieTargets,
} from './nutritionCalculator'

export interface RankContext {
  targets: CalorieTargets
  recentMealIds?: string[]            // used earlier this week / last week
  favoriteIds?: string[]
  coverageByMeal?: Record<string, number> // 0..1 nearby price coverage; missing = unknown
  relax?: { budget?: boolean; prep?: boolean; cooking?: boolean }
}
export interface ScoredMeal { meal: Meal; score: number; confidence: 'high' | 'medium' | 'low'; parts: Record<string, number> }

const clamp01 = (n: number) => Math.max(0, Math.min(1, n))
const fit = (value: number, target: number, tolerance: number) => clamp01(1 - Math.abs(value - target) / (target * tolerance))
const NO_COOK_CATS = ['no-cook', 'grocery-prepared', 'restaurant']

export function passesConstraints(meal: Meal, p: UserProfile, relax: RankContext['relax'] = {}): boolean {
  if (!relax.budget && meal.estimatedCostPerServing > p.maxPricePerMeal) return false
  if (!relax.prep && meal.prepMinutes > p.maxPrepMinutes) return false
  if (!relax.cooking) {
    if (p.cooking === 'no-cook' && !meal.categories.some(c => NO_COOK_CATS.includes(c))) return false
    if (p.cooking === 'minimal' && meal.prepMinutes > 20) return false
  }
  return true
}

/** Safety (allergies, diet, dislikes) → slot → calorie window → user constraints. */
export function eligibleMeals(all: Meal[], p: UserProfile, slot: MealType, ctx: RankContext): Meal[] {
  const target = mealCalorieTarget(ctx.targets, slot)
  return all.filter(m => m.mealType.includes(slot) && isMealSafe(m, p) && calorieEligible(m, target) && passesConstraints(m, p, ctx.relax))
}

export function scoreMeal(meal: Meal, p: UserProfile, slot: MealType, ctx: RankContext): ScoredMeal {
  const calTarget = mealCalorieTarget(ctx.targets, slot)
  const proteinTarget = mealProteinTarget(ctx.targets, slot)
  const mealBudget = Math.min(p.maxPricePerMeal, p.dailyFoodBudget * 0.35)
  const budget = meal.estimatedCostPerServing <= mealBudget ? 1 : clamp01(1 - (meal.estimatedCostPerServing - mealBudget) / mealBudget)
  const convenience = clamp01(1 - meal.prepMinutes / Math.max(10, p.maxPrepMinutes)) * 0.7 + (meal.categories.includes('quick') ? 0.3 : 0)
  const wantsCook = p.cooking === 'enjoy-cooking'
  const preference = (ctx.favoriteIds?.includes(meal.id) ? 0.6 : 0) + (wantsCook ? clamp01(meal.prepMinutes / 40) * 0.4 : 0.4) +
    (dietRank(p.diet) > 0 && mealDietLevel(meal) === dietRank(p.diet) ? 0.0 : 0)
  const recentIdx = ctx.recentMealIds?.lastIndexOf(meal.id) ?? -1
  const variety = recentIdx < 0 ? 1 : 0
  const cov = ctx.coverageByMeal?.[meal.id]
  const parts = {
    nutritionFit: fit(meal.calories, calTarget, 0.5), proteinFit: clamp01(meal.protein / Math.max(1, proteinTarget)),
    budgetFit: budget, convenience, preference: clamp01(preference), variety, localCoverage: cov ?? 0,
  }
  const score = (Object.keys(parts) as (keyof typeof parts)[]).reduce((s, k) => s + parts[k] * W[k], 0)
  const confidence = cov === undefined || meal.ingredients.length === 0 ? 'low' : cov >= 0.9 ? 'high' : 'medium'
  return { meal, score, confidence, parts }
}

export function rankMeals(all: Meal[], p: UserProfile, slot: MealType, ctx: RankContext): ScoredMeal[] {
  return eligibleMeals(all, p, slot, ctx)
    .map(m => scoreMeal(m, p, slot, ctx))
    .sort((a, b) => b.score - a.score || a.meal.id.localeCompare(b.meal.id))
}

export const defaultContext = (p: UserProfile): RankContext => ({ targets: calcTargets(p) })

// ---- Swap ----
export type SwapMode = 'cheapest' | 'high-protein' | 'faster' | 'different' | 'vegetarian' | 'restaurant' | 'grocery-prepared'
export const swapModes: { id: SwapMode; label: string }[] = [
  { id: 'cheapest', label: 'Cheapest supported option' }, { id: 'high-protein', label: 'Higher protein' },
  { id: 'faster', label: 'Faster' }, { id: 'different', label: 'Different meal' },
  { id: 'vegetarian', label: 'Vegetarian' }, { id: 'restaurant', label: 'Restaurant' }, { id: 'grocery-prepared', label: 'Prepared grocery meal' },
]
/** Always runs through the safety gate. Constraints are relaxed only for budget/prep/cooking so swaps are not empty. */
export function swapCandidates(all: Meal[], p: UserProfile, slot: MealType, current: Meal | undefined, mode: SwapMode,
  ctx: RankContext, excludeIds: string[] = []): ScoredMeal[] {
  const pool = (relax: RankContext['relax']) => rankMeals(all, p, slot, { ...ctx, relax })
    .filter(s => s.meal.id !== current?.id && !excludeIds.includes(s.meal.id))
  let list = pool(mode === 'restaurant' || mode === 'grocery-prepared' ? { budget: true, prep: true, cooking: true } : ctx.relax)
  if (!list.length) list = pool({ budget: true, prep: true, cooking: true })
  switch (mode) {
    case 'cheapest': return [...list].sort((a, b) => a.meal.estimatedCostPerServing - b.meal.estimatedCostPerServing)
    case 'high-protein': return [...list].filter(s => !current || s.meal.protein > current.protein).sort((a, b) => b.meal.protein - a.meal.protein)
    case 'faster': return [...list].filter(s => !current || s.meal.prepMinutes < current.prepMinutes).sort((a, b) => a.meal.prepMinutes - b.meal.prepMinutes)
    case 'vegetarian': return list.filter(s => mealDietLevel(s.meal) <= 1)
    case 'restaurant': return list.filter(s => s.meal.categories.includes('restaurant'))
    case 'grocery-prepared': return list.filter(s => s.meal.categories.includes('grocery-prepared'))
    default: return list
  }
}

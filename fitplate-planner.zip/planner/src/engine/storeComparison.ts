import type { GroceryPrice, IngredientRequirement, PriceType, Store } from '../types'
import { storeComparisonWeights as W, minCoverageForConfidentClaim, splitMinSavingFraction, splitMinSavingUsd } from '../config/storeComparisonWeights'
import { convert } from './unitConversion'
import { effectivePrice, matchRequirement, type MatchConfidence } from './productMatching'

export type MissingReason = 'no-product' | 'out-of-stock' | 'unit-incompatible'
export interface MissingIngredient { ingredientId: string; name: string; reason: MissingReason }
export interface UncertainMatch { ingredientId: string; name: string; productName: string }
export interface PricedLine {
  ingredientId: string; name: string; productName: string; confidence: MatchConfidence
  packagesNeeded: number; packagePrice: number; checkoutCost: number; usageCost: number; priceType: PriceType; retrievedAt?: string
}
export interface StoreComparison {
  store: Store
  totalCheckoutCost: number          // whole packages you would buy
  estimatedUsageCost: number         // only the quantity the recipe/list uses
  mealCostPerServing: number         // usage cost / servings
  distanceMiles: number              // approximate straight-line
  pricedIngredientCount: number
  totalIngredientCount: number
  coveragePercent: number
  missingIngredients: MissingIngredient[]
  uncertainMatches: UncertainMatch[]
  priceType: PriceType
  latestRetrievedAt?: string          // only set when genuinely retrieved (live) data was used
  score: number
  scoreBreakdown: { price: number; distance: number; coverage: number; availability: number }
  comparableCost: number | null      // usage cost over ingredients priced at every ranked store
  lines: PricedLine[]
  explanation: string
}
export interface ComparisonResult {
  rows: StoreComparison[]
  unsupportedStores: Store[]
  best?: StoreComparison
  confident: boolean
  headline: string
}
export interface CompareInput {
  requirements: IngredientRequirement[]; servings: number; stores: Store[]; prices: GroceryPrice[]; radiusMiles: number
}
export type SortKey = 'checkout' | 'perServing' | 'closest' | 'bestValue'

const EPS = 1e-9
const rollupType = (types: PriceType[]): PriceType =>
  types.length && types.every(t => t === 'live') ? 'live' : types.includes('sample') ? 'sample' : 'estimated'

export function priceStore(store: Store, input: CompareInput): StoreComparison {
  const storePrices = input.prices.filter(p => p.storeId === store.id)
  const lines: PricedLine[] = [], missing: MissingIngredient[] = [], uncertain: UncertainMatch[] = []
  for (const req of input.requirements) {
    const m = matchRequirement(req, storePrices)
    const base = { ingredientId: req.ingredientId, name: req.name }
    if (!m.price || m.confidence === 'unmatched') { missing.push({ ...base, reason: 'no-product' }); continue }
    if (m.confidence === 'uncertain') { uncertain.push({ ...base, productName: m.price.productName }); continue }
    if (m.price.availability === 'out-of-stock') { missing.push({ ...base, reason: 'out-of-stock' }); continue }
    const q = convert(req.quantity, req.unit, m.price.packageUnit as never, m.price.ingredientId)
    if (q === null || m.price.packageQuantity <= 0) { missing.push({ ...base, reason: 'unit-incompatible' }); continue }
    const unitPrice = effectivePrice(m.price)
    const packages = Math.max(1, Math.ceil(q / m.price.packageQuantity - EPS))
    lines.push({
      ...base, productName: m.price.productName, confidence: m.confidence, packagesNeeded: packages, packagePrice: unitPrice,
      checkoutCost: packages * unitPrice, usageCost: (q / m.price.packageQuantity) * unitPrice, priceType: m.price.priceType, retrievedAt: m.price.retrievedAt,
    })
  }
  const total = input.requirements.length
  const checkout = lines.reduce((s, l) => s + l.checkoutCost, 0)
  const usage = lines.reduce((s, l) => s + l.usageCost, 0)
  return {
    store, totalCheckoutCost: checkout, estimatedUsageCost: usage, mealCostPerServing: usage / Math.max(1, input.servings),
    distanceMiles: store.distanceMiles, pricedIngredientCount: lines.length, totalIngredientCount: total,
    coveragePercent: total ? Math.round((lines.length / total) * 100) : 0, missingIngredients: missing, uncertainMatches: uncertain,
    priceType: rollupType(lines.map(l => l.priceType)),
    latestRetrievedAt: lines.map(l => l.retrievedAt).filter((x): x is string => !!x).sort().pop(), score: 0, scoreBreakdown: { price: 0, distance: 0, coverage: 0, availability: 0 },
    comparableCost: null, lines, explanation: '',
  }
}

export function compareStores(input: CompareInput): ComparisonResult {
  const supported = input.stores.filter(s => s.supportedPricing)
  const unsupportedStores = input.stores.filter(s => !s.supportedPricing)
  const rows = supported.map(s => priceStore(s, input))
  const priced = rows.filter(r => r.pricedIngredientCount > 0)

  // Fair price comparison: only ingredients priced at every ranked store
  const ids = priced.map(r => new Set(r.lines.map(l => l.ingredientId)))
  const common = ids.length ? [...ids[0]].filter(id => ids.every(s => s.has(id))) : []
  priced.forEach(r => { r.comparableCost = common.length ? r.lines.filter(l => common.includes(l.ingredientId)).reduce((s, l) => s + l.usageCost, 0) : null })
  const minComparable = Math.min(...priced.map(r => r.comparableCost ?? Infinity))

  for (const r of rows) {
    const covered = r.pricedIngredientCount > 0
    const price = covered && r.comparableCost ? Math.min(1, minComparable / r.comparableCost) : 0
    const dist = Math.max(0, 1 - r.distanceMiles / Math.max(0.1, input.radiusMiles))
    const coverage = r.coveragePercent / 100
    const availability = covered ? 1 : 0 // stock-outs are already removed from priced lines
    const raw = { price: price * W.priceWeight, distance: dist * W.distanceWeight, coverage: coverage * W.coverageWeight, availability: availability * W.availabilityWeight }
    r.scoreBreakdown = { price: Math.round(raw.price * 100), distance: Math.round(raw.distance * 100), coverage: Math.round(raw.coverage * 100), availability: Math.round(raw.availability * 100) }
    r.score = Math.round((raw.price + raw.distance + raw.coverage + raw.availability) * 100)
  }
  const ranked = [...priced].sort((a, b) => b.score - a.score)
  const best = ranked[0]
  const confident = priced.length > 0 && priced.every(r => r.coveragePercent / 100 >= minCoverageForConfidentClaim)
  for (const r of rows) r.explanation = explain(r, r === best, common.length > 0 && r.comparableCost === minComparable, input.radiusMiles)
  return {
    rows, unsupportedStores, best, confident,
    headline: !best ? 'No price data available' : confident ? 'Lowest estimated cost among supported stores' : 'Lowest price among supported stores with available data',
  }
}

function explain(r: StoreComparison, isBest: boolean, lowestPrice: boolean, radius: number): string {
  if (r.pricedIngredientCount === 0) return 'No usable price data for this store.'
  const bits: string[] = []
  bits.push(r.coveragePercent >= minCoverageForConfidentClaim * 100 ? `high ingredient coverage (${r.coveragePercent}%)` : `partial ingredient coverage (${r.coveragePercent}%)`)
  if (lowestPrice) bits.push('the lowest supported estimate on comparable items')
  bits.push(r.distanceMiles <= radius ? `is within your ${radius} mi preferred radius (approx., straight-line)` : 'is outside your preferred radius')
  return `${isBest ? 'Best value because it has' : 'Score reflects'} ${bits.join(', ')}.`
}

export function sortComparisons(rows: StoreComparison[], key: SortKey): StoreComparison[] {
  const withData = rows.filter(r => r.pricedIngredientCount > 0), without = rows.filter(r => r.pricedIngredientCount === 0)
  const by: Record<SortKey, (a: StoreComparison, b: StoreComparison) => number> = {
    checkout: (a, b) => a.totalCheckoutCost - b.totalCheckoutCost || b.coveragePercent - a.coveragePercent,
    perServing: (a, b) => a.mealCostPerServing - b.mealCostPerServing || b.coveragePercent - a.coveragePercent,
    closest: (a, b) => a.distanceMiles - b.distanceMiles,
    bestValue: (a, b) => b.score - a.score,
  }
  return [...withData.sort(by[key]), ...without]
}

// ---- Split-store option ----
export interface SplitBasket {
  storesUsed: Store[]; total: number; coveredCount: number; totalCount: number; missing: MissingIngredient[]
  singleStoreTotal?: number; saving?: number; extraDistanceMiles?: number; recommended: boolean; message: string
}
export function splitBasket(input: CompareInput, result: ComparisonResult): SplitBasket {
  const best = result.best
  const chosen = new Map<string, { store: Store; cost: number }>()
  const missing: MissingIngredient[] = []
  for (const req of input.requirements) {
    let pick: { store: Store; cost: number } | undefined
    for (const r of result.rows) {
      const line = r.lines.find(l => l.ingredientId === req.ingredientId)
      if (line && (!pick || line.checkoutCost < pick.cost)) pick = { store: r.store, cost: line.checkoutCost }
    }
    if (pick) chosen.set(req.ingredientId, pick)
    else missing.push({ ingredientId: req.ingredientId, name: req.name, reason: 'no-product' })
  }
  const storesUsed = [...new Map([...chosen.values()].map(c => [c.store.id, c.store])).values()]
  const total = [...chosen.values()].reduce((s, c) => s + c.cost, 0)
  const singleTotal = best && best.coveragePercent === 100 ? best.totalCheckoutCost : undefined
  const saving = singleTotal !== undefined && missing.length === 0 ? singleTotal - total : undefined
  const extra = best ? 2 * storesUsed.reduce((s, x) => s + x.distanceMiles, 0) - 2 * best.distanceMiles : undefined
  const worthIt = saving !== undefined && storesUsed.length > 1 && saving >= splitMinSavingUsd && saving >= singleTotal! * splitMinSavingFraction
  let message: string
  if (storesUsed.length <= 1) message = 'A single store already covers the cheapest option for every priced item.'
  else if (saving === undefined) message = 'Not enough comparable data to say whether splitting saves money. One store is recommended.'
  else if (worthIt) message = `Splitting may save about $${saving.toFixed(2)} (estimate) but adds roughly ${Math.max(0, extra ?? 0).toFixed(1)} mi of straight-line round-trip distance.`
  else message = `Estimated saving of $${Math.max(0, saving).toFixed(2)} is small compared with visiting ${storesUsed.length} stores. One store is recommended.`
  return {
    storesUsed, total, coveredCount: chosen.size, totalCount: input.requirements.length, missing,
    singleStoreTotal: singleTotal, saving, extraDistanceMiles: extra, recommended: worthIt, message,
  }
}

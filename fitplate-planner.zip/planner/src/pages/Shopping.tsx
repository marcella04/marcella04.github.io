import { useApp } from '../state/AppContext'
import { useWeeklyBasket } from '../hooks/useWeeklyBasket'
import { Badge, Button, Card, EmptyState } from '../components/UI'
import { StoreComparisonView } from '../components/Stores/StoreComparisonView'
import { weekLabel } from '../utils/dates'
import type { ShoppingItem } from '../types'
import { useNavigate } from 'react-router-dom'

export default function ShoppingPage() {
  const app = useApp()
  const nav = useNavigate()
  const { items, requirements, mealCount } = useWeeklyBasket()
  const { state } = app.shopping
  if (!app.plan) return <EmptyState title="No shopping list yet" action={<Button variant="primary" onClick={() => nav('/')}>Go to My Plan</Button>}>Generate a plan for this week and your shopping list will appear here.</EmptyState>
  const visible = items.filter(i => !state.removed.includes(i.key))
  const groups = (pantry: boolean) => Object.entries(visible.filter(i => i.pantry === pantry).reduce<Record<string, ShoppingItem[]>>((a, i) => ((a[i.category] ??= []).push(i), a), {}))
  const done = visible.filter(i => state.checked.includes(i.key) || app.owned.includes(i.ingredientId)).length
  const sel = app.nearby.stores.find(s => s.id === app.selectedStores[app.weekStart])

  const section = (title: string, pantry: boolean) => {
    const g = groups(pantry); if (!g.length) return null
    return (
      <Card key={title}><h2 className="mb-2 font-semibold text-teal-900">{title}</h2>
        {g.map(([cat, list]) => (
          <div key={cat} className="mb-3"><h3 className="text-xs font-semibold uppercase text-stone-500">{cat}</h3>
            <ul className="divide-y divide-stone-100">{list.map(i => {
              const owned = app.owned.includes(i.ingredientId), checked = state.checked.includes(i.key) || owned
              return (
                <li key={i.key} className="flex flex-wrap items-center gap-2 py-1.5 text-sm">
                  <label className="flex flex-1 items-center gap-2"><input type="checkbox" checked={checked} disabled={owned} onChange={() => app.shopping.toggleChecked(i.key)} />
                    <span className={checked ? 'text-stone-500 line-through' : ''}>{i.name}: <strong>{i.quantity} {i.unit}</strong></span></label>
                  {owned && <Badge tone="teal">Already owned</Badge>}
                  <Button size="sm" onClick={() => app.shopping.toggleOwned(i.ingredientId)} aria-pressed={owned}>{owned ? 'Not owned' : 'I have this'}</Button>
                  <Button size="sm" variant="ghost" onClick={() => app.shopping.remove(i.key)} aria-label={`Remove ${i.name}`}>Remove</Button>
                </li>)
            })}</ul></div>))}
      </Card>
    )
  }
  return (
    <div className="space-y-4">
      <div><h1 className="text-2xl font-bold">Shopping</h1><p className="text-sm text-stone-600">Week of {weekLabel(app.weekStart)} · {mealCount} planned meals · {done}/{visible.length} items done</p></div>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-4">
          {section('Groceries', false)}
          {section('Pantry staples', true)}
          {state.removed.length > 0 && <Button onClick={app.shopping.restoreAll}>Restore {state.removed.length} removed item(s)</Button>}
          {!visible.length && <EmptyState title="Your list is empty">All items were removed or the plan has no grocery ingredients.</EmptyState>}
          <p className="text-xs text-stone-600">Quantities cover one serving of each planned meal. Items you own or remove are left out of the estimate below.</p>
        </div>
        <div className="space-y-3">
          <Card className="bg-teal-50/60"><h2 className="font-semibold text-teal-900">Weekly Grocery Estimate</h2>
            <p className="text-sm text-stone-700">Compare your full basket across supported nearby stores. One store is recommended by default.</p>
            {sel && <p className="mt-1 text-sm">Your selected store: <strong>{sel.name}</strong></p>}</Card>
          <StoreComparisonView requirements={requirements} servings={Math.max(1, mealCount)} perLabel="per planned meal" weekly />
        </div>
      </div>
    </div>
  )
}

import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../state/AppContext'
import { Button, Card, EmptyState, Notice } from '../components/UI'
import { DayCard, type PlanModal } from '../components/Calendar/DayCard'
import { LocationPrompt } from '../components/Location/LocationControls'
import { MealDetailsModal } from '../components/Meals/MealDetailsModal'
import { SwapMealModal } from '../components/Meals/SwapMealModal'
import { MealCompareModal } from '../components/Meals/MealCompareModal'
import { WorkoutModal } from '../components/Workouts/WorkoutModal'
import { mealById } from '../data/meals'
import { workoutById } from '../data/workouts'
import { addDays, mondayOf, weekLabel } from '../utils/dates'
import { calcTargets } from '../engine/nutritionCalculator'
import { money } from '../utils/format'

export default function CalendarPage() {
  const app = useApp()
  const nav = useNavigate()
  const [modal, setModal] = useState<PlanModal | null>(null)
  const { plan, weekStart, profile } = app
  const thisWeek = mondayOf(new Date())
  const targets = profile ? calcTargets(profile) : null
  const planned = plan?.days.flatMap(d => [d.lunchId, d.dinnerId]).map(id => (id ? mealById[id] : undefined)).filter(Boolean) ?? []
  const weekCost = planned.reduce((s, m) => s + (m?.estimatedCostPerServing ?? 0), 0)
  const dayKcal = plan && plan.days.length ? planned.reduce((s, m) => s + (m?.calories ?? 0), 0) / 7 : 0
  const close = () => setModal(null)
  const day = modal ? plan?.days.find(d => d.date === modal.date) : undefined
  const mealOf = (m: Extract<PlanModal, { slot: unknown }>) => { const id = m.slot === 'lunch' ? day?.lunchId : day?.dinnerId; return id ? mealById[id] : undefined }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h1 className="text-2xl font-bold">My Plan</h1><p className="text-sm text-stone-600" aria-live="polite">{weekLabel(weekStart)}{weekStart === thisWeek ? ' · this week' : ''}</p></div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => app.setWeekStart(addDays(weekStart, -7))}>← Previous Week</Button>
          <Button onClick={() => app.setWeekStart(thisWeek)} disabled={weekStart === thisWeek}>Current Week</Button>
          <Button onClick={() => app.setWeekStart(addDays(weekStart, 7))}>Next Week →</Button>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant="primary" onClick={() => app.generate()}>{plan ? 'Regenerate My Week' : 'Generate My Week'}</Button>
        <Button variant="teal" disabled={!plan} onClick={() => nav('/shopping')}>Generate Shopping List</Button>
      </div>
      {app.locationPref.mode === 'unset' && <LocationPrompt />}
      {plan?.warnings.map(w => <Notice key={w} tone="warning">{w}</Notice>)}
      {plan && targets && (
        <Card className="text-sm text-stone-700">
          Average planned lunch + dinner: <strong>{Math.round(dayKcal)} kcal/day</strong> (≈ {targets.lunch + targets.dinner} kcal planned for those two meals; daily estimate {targets.dailyTarget} kcal). Estimated meal cost this week: <strong>{money(weekCost)}</strong> of {money(profile!.weeklyGroceryBudget)} budget.
        </Card>)}
      {plan ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7">
          {plan.days.map(d => <DayCard key={d.date} day={d} open={setModal} />)}
        </div>
      ) : (
        <EmptyState title="No plan for this week yet" action={<Button variant="primary" onClick={() => app.generate()}>Generate My Week</Button>}>Create lunches, dinners and workouts for Monday through Sunday based on your profile.</EmptyState>
      )}
      {modal && modal.kind !== 'workout' && (() => {
        const meal = mealOf(modal)
        if (modal.kind === 'swap') return <SwapMealModal current={meal} slot={modal.slot} date={modal.date} onClose={close} />
        if (!meal) return null
        if (modal.kind === 'compare') return <MealCompareModal meal={meal} onClose={close} />
        return <MealDetailsModal meal={meal} slot={modal.slot} date={modal.date} onClose={close}
          onSwap={() => setModal({ ...modal, kind: 'swap' })} onCompare={() => setModal({ ...modal, kind: 'compare' })} />
      })()}
      {modal?.kind === 'workout' && day?.workoutId && <WorkoutModal workout={workoutById[day.workoutId]} date={modal.date} onClose={close} />}
    </div>
  )
}

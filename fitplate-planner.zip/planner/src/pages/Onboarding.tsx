import { useNavigate } from 'react-router-dom'
import { useApp } from '../state/AppContext'
import { defaultProfile, ProfileForm } from '../components/Layout/ProfileForm'
import { Disclaimer } from '../components/Layout/Disclaimer'
import { Card } from '../components/UI'

export default function OnboardingPage() {
  const app = useApp()
  const nav = useNavigate()
  return (
    <div className="mx-auto max-w-3xl space-y-4 px-4 py-6">
      <header><h1 className="text-3xl font-bold text-emerald-900">🥗 Welcome to FitPlate</h1>
        <p className="mt-1 text-stone-700">A free planner for lunch, dinner and workouts for every day of the week. Tell us a bit about you — you can change everything later.</p></header>
      <Card className="bg-violet-50 text-sm text-violet-900">This is a demo build. Meals, nutrition, nearby stores and prices are sample or estimated data.</Card>
      <ProfileForm initial={app.profile ?? defaultProfile} submitLabel="Save and build my week" onSubmit={p => { app.setProfile(p); app.generate(app.weekStart, p); nav('/') }} />
      <Disclaimer />
    </div>
  )
}

import { useMemo, useState } from 'react'
import { useApp } from '../state/AppContext'
import { useWeeklyBasket } from '../hooks/useWeeklyBasket'
import { useComparison } from '../hooks/useComparison'
import { Button, Card, EmptyState } from '../components/UI'
import { mealById } from '../data/meals'
import { workoutById } from '../data/workouts'
import { iso, weekLabel, weekDates } from '../utils/dates'
import { money } from '../utils/format'

function WeightChart({ data }: { data: { date: string; weightLb: number }[] }) {
  if (data.length < 2) return null
  const w = 600, h = 180, pad = 28
  const min = Math.min(...data.map(d => d.weightLb)) - 1, max = Math.max(...data.map(d => d.weightLb)) + 1
  const pts = data.map((d, i) => [pad + (i / (data.length - 1)) * (w - 2 * pad), h - pad - ((d.weightLb - min) / (max - min)) * (h - 2 * pad)])
  return (
    <svg viewBox={`0 0 ${w} ${h}`} role="img" aria-label={`Weight from ${data[0].weightLb} lb to ${data[data.length - 1].weightLb} lb across ${data.length} entries`} className="w-full">
      <polyline fill="none" stroke="#047857" strokeWidth="2.5" points={pts.map(p => p.join(',')).join(' ')} />
      {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="4" fill="#047857" />)}
      <text x={4} y={14} fontSize="11" fill="#57534e">{max.toFixed(0)} lb</text><text x={4} y={h - 8} fontSize="11" fill="#57534e">{min.toFixed(0)} lb</text>
    </svg>
  )
}

export default function ProgressPage() {
  const app = useApp()
  const [date, setDate] = useState(iso(new Date()))
  const [lb, setLb] = useState('')
  const [err, setErr] = useState('')
  const { requirements, mealCount } = useWeeklyBasket()
  const cmp = useComparison(requirements, Math.max(1, mealCount))

  const weeks = useMemo(() => Object.values(app.plans).sort((a, b) => b.weekStart.localeCompare(a.weekStart)).slice(0, 6).map(p => {
    const dates = new Set(weekDates(p.weekStart))
    const mealsPlanned = p.days.reduce((n, d) => n + (d.lunchId ? 1 : 0) + (d.dinnerId ? 1 : 0), 0)
    const workoutsPlanned = p.days.filter(d => d.workoutId && workoutById[d.workoutId]?.category !== 'rest').length
    const done = app.completedMeals.filter(c => dates.has(c.date)).length + app.completedWorkouts.filter(c => dates.has(c.date)).length
    const total = mealsPlanned + workoutsPlanned
    return { weekStart: p.weekStart, done, total, pct: total ? Math.round((done / total) * 100) : 0 }
  }), [app.plans, app.completedMeals, app.completedWorkouts])

  const spendAll = app.completedMeals.reduce((s, c) => s + (mealById[c.mealId]?.estimatedCostPerServing ?? 0), 0)
  const thisWeekDates = new Set(weekDates(app.weekStart))
  const spendWeek = app.completedMeals.filter(c => thisWeekDates.has(c.date)).reduce((s, c) => s + (mealById[c.mealId]?.estimatedCostPerServing ?? 0), 0)
  const comparable = cmp?.result.rows.map(r => r.comparableCost).filter((x): x is number => x !== null) ?? []
  const savings = comparable.length > 1 ? Math.max(...comparable) - Math.min(...comparable) : null
  const checkedCount = app.shopping.state.checked.length
  const listTotal = useWeeklyBasket().items.length

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    const n = Number(lb)
    if (!(n >= 70 && n <= 700)) { setErr('Enter a weight between 70 and 700 lb.'); return }
    if (!date || date > iso(new Date())) { setErr('Choose today or an earlier date.'); return }
    setErr(''); app.addWeight(date, n); setLb('')
  }
  const wh = app.weightHistory
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Progress</h1>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card><h2 className="font-semibold text-emerald-900">Weight</h2>
          <form onSubmit={submit} className="mt-2 flex flex-wrap items-end gap-2" noValidate>
            <div><label htmlFor="wdate" className="block text-sm">Date</label><input id="wdate" type="date" value={date} max={iso(new Date())} onChange={e => setDate(e.target.value)} className="rounded-lg border border-stone-300 px-2 py-1.5 text-sm" /></div>
            <div><label htmlFor="wlb" className="block text-sm">Weight (lb)</label><input id="wlb" inputMode="decimal" value={lb} onChange={e => setLb(e.target.value)} className="w-24 rounded-lg border border-stone-300 px-2 py-1.5 text-sm" /></div>
            <Button type="submit" variant="primary">Add entry</Button>
          </form>
          {err && <p role="alert" className="mt-2 text-sm text-red-700">{err}</p>}
          {wh.length ? (<><div className="mt-3"><WeightChart data={wh} /></div>
            <table className="mt-2 w-full text-sm"><caption className="sr-only">Weight entries</caption><thead><tr className="text-left text-xs text-stone-500"><th scope="col">Date</th><th scope="col">Weight</th><th scope="col"><span className="sr-only">Actions</span></th></tr></thead>
              <tbody>{[...wh].reverse().slice(0, 8).map(w => <tr key={w.date}><td>{w.date}</td><td>{w.weightLb} lb</td><td className="text-right"><Button size="sm" variant="ghost" onClick={() => app.removeWeight(w.date)} aria-label={`Delete entry ${w.date}`}>Delete</Button></td></tr>)}</tbody></table></>)
            : <div className="mt-3"><EmptyState title="No weight entries yet">Add a measurement whenever you like. Weight naturally fluctuates day to day.</EmptyState></div>}
        </Card>
        <div className="space-y-4">
          <Card><h2 className="font-semibold text-emerald-900">Weekly adherence</h2>
            {weeks.length ? <ul className="mt-2 space-y-2">{weeks.map(w => (
              <li key={w.weekStart} className="text-sm"><div className="flex justify-between"><span>{weekLabel(w.weekStart)}</span><span>{w.done}/{w.total} ({w.pct}%)</span></div>
                <div className="mt-1 h-2 rounded bg-stone-200" role="img" aria-label={`${w.pct}% of planned meals and workouts completed`}><div className="h-full rounded bg-emerald-600" style={{ width: `${w.pct}%` }} /></div></li>))}</ul>
              : <p className="mt-2 text-sm text-stone-600">Generate a plan to start tracking.</p>}
          </Card>
          <Card><h2 className="font-semibold text-teal-900">Spending & shopping</h2>
            <ul className="mt-2 space-y-1 text-sm">
              <li>Estimated food spending this week (eaten meals): <strong>{money(spendWeek)}</strong>; all time: <strong>{money(spendAll)}</strong></li>
              <li>Estimated possible store savings on comparable items: <strong>{savings === null ? 'not enough data' : `about ${money(savings)}`}</strong> <span className="text-xs text-stone-600">(estimate from sample data, not exact)</span></li>
              <li>Grocery list completion: <strong>{listTotal ? Math.round((checkedCount / listTotal) * 100) : 0}%</strong> ({checkedCount} of {listTotal} items checked off)</li>
              <li>Favorite meals: <strong>{app.favorites.length}</strong></li>
            </ul></Card>
        </div>
      </div>
    </div>
  )
}

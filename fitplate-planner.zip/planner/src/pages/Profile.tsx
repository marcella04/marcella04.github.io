import { useState } from 'react'
import { useApp } from '../state/AppContext'
import { ProfileForm } from '../components/Layout/ProfileForm'
import { LocationSettings } from '../components/Location/LocationControls'
import { Button, Card, Notice } from '../components/UI'

export default function ProfilePage() {
  const app = useApp()
  const [saved, setSaved] = useState(false)
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Profile</h1>
      <LocationSettings />
      {saved && <Notice>✓ Profile saved. Regenerate your week on My Plan to apply changes to meals and workouts.</Notice>}
      <ProfileForm initial={app.profile!} submitLabel="Save profile" onSubmit={p => { app.setProfile(p); setSaved(true); window.scrollTo({ top: 0, behavior: 'smooth' }) }} />
      <Card><h2 className="font-semibold">Your data</h2><p className="mt-1 text-sm text-stone-600">Everything is stored in this browser only.</p>
        <Button variant="danger" className="mt-2" onClick={() => { if (window.confirm('Delete all saved data from this browser?')) app.resetAll() }}>Delete all saved data</Button></Card>
    </div>
  )
}

// Product-design settings for "best value". NOT medically validated.
export const storeComparisonWeights = {
  priceWeight: 0.4, distanceWeight: 0.2, coverageWeight: 0.3, availabilityWeight: 0.1,
} as const
/** Coverage every compared store must reach before we make a confident "lowest" claim. */
export const minCoverageForConfidentClaim = 0.9
/** Split-store: minimum saving (USD and fraction) before a multi-store trip is suggested. */
export const splitMinSavingUsd = 5
export const splitMinSavingFraction = 0.1

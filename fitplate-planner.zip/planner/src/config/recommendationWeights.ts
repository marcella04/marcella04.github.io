// Product-design weights (sum to 1). NOT medically validated.
export const recommendationWeights = {
  nutritionFit: 0.25, proteinFit: 0.2, budgetFit: 0.18, convenience: 0.12,
  preference: 0.05, variety: 0.12, localCoverage: 0.08,
} as const
// Meal share of daily energy target (remainder = breakfast/snacks). Estimates only.
export const mealShare = { lunch: 0.3, dinner: 0.35 } as const
// Eligible calories relative to meal target
export const calorieBounds = { min: 0.6, max: 1.3 } as const

import type { Store } from '../../types'
import { DEMO_ADDRESS, demoStoreSpecs } from '../../data/stores'
import { haversineMiles } from '../../engine/distanceCalculator'
import type { StoreProvider, StoreQuery } from './StoreProvider'

/** Demo stores positioned as offsets from the search centre. Distances are approximate straight-line miles. */
export class MockStoreProvider implements StoreProvider {
  async findNearby(q: StoreQuery): Promise<Store[]> {
    const centre = { latitude: q.latitude, longitude: q.longitude }
    return demoStoreSpecs.map(s => {
      const latitude = q.latitude + s.dyMi / 69
      const longitude = q.longitude + s.dxMi / (69 * Math.cos((q.latitude * Math.PI) / 180))
      return {
        id: s.id, name: s.name, chain: s.chain, address: DEMO_ADDRESS, latitude, longitude,
        distanceMiles: haversineMiles(centre, { latitude, longitude }), supportedPricing: s.supportedPricing, dataSource: 'demo' as const,
      }
    }).filter(s => s.distanceMiles <= q.radiusMiles && (!q.supportedChains || q.supportedChains.includes(s.chain)))
      .sort((a, b) => a.distanceMiles - b.distanceMiles)
  }
}

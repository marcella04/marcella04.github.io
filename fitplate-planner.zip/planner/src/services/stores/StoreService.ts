import type { Store } from '../../types'
import { MockStoreProvider } from './MockStoreProvider'
import type { StoreProvider, StoreQuery } from './StoreProvider'

export class StoreService {
  constructor(private provider: StoreProvider = new MockStoreProvider()) {}
  setProvider(p: StoreProvider) { this.provider = p }
  async nearby(q: StoreQuery): Promise<Store[]> {
    if (!(q.radiusMiles > 0)) return []
    return (await this.provider.findNearby(q)).sort((a, b) => a.distanceMiles - b.distanceMiles)
  }
}
export const storeService = new StoreService()

import type { Store } from '../../types'

export interface StoreQuery { latitude: number; longitude: number; radiusMiles: number; supportedChains?: string[] }
/** Implement against a real places API on the SERVER; see README → "Add a real place provider". */
export interface StoreProvider { findNearby(q: StoreQuery): Promise<Store[]> }

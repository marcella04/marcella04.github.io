import type { LocationPreference } from '../../types'
import { BrowserLocationProvider } from './BrowserLocationProvider'
import { ZipCodeLocationProvider } from './ZipCodeLocationProvider'

/** Single entry point for UI code. Only called from explicit button handlers. */
export const locationService = {
  fromBrowser: () => new BrowserLocationProvider().getLocation(),
  fromZip: (zipCode: string) => new ZipCodeLocationProvider().getLocation({ zipCode }),
}
export const hasLocation = (p: LocationPreference) => (p.mode === 'browser' || p.mode === 'zip') && !!p.location

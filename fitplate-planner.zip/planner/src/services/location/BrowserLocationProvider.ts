import type { UserLocation } from '../../types'
import { LocationError, roundCoord, type LocationProvider } from './LocationProvider'

/** The ONLY module that touches navigator.geolocation. One-shot lookup — no watchPosition, no history. */
export class BrowserLocationProvider implements LocationProvider {
  getLocation(): Promise<UserLocation> {
    return new Promise((resolve, reject) => {
      if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
        reject(new LocationError('unsupported', 'This browser does not support location. Enter a ZIP code instead.')); return
      }
      navigator.geolocation.getCurrentPosition(
        pos => resolve({
          latitude: roundCoord(pos.coords.latitude), longitude: roundCoord(pos.coords.longitude),
          source: 'browser', accuracyMeters: Math.round(pos.coords.accuracy), updatedAt: new Date().toISOString(),
        }),
        err => reject(
          err.code === err.PERMISSION_DENIED ? new LocationError('denied', 'Location permission was denied. You can enter a ZIP code instead.')
          : err.code === err.TIMEOUT ? new LocationError('timeout', 'Finding your location took too long. Try again or enter a ZIP code.')
          : new LocationError('unavailable', 'Your location is currently unavailable. Try again or enter a ZIP code.')),
        { enableHighAccuracy: false, timeout: 10000, maximumAge: 5 * 60 * 1000 },
      )
    })
  }
}
export const isInaccurate = (loc: UserLocation) => loc.source === 'browser' && (loc.accuracyMeters ?? 0) > 5000

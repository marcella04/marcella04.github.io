import type { UserLocation } from '../../types'

export type LocationErrorCode = 'denied' | 'unavailable' | 'timeout' | 'unsupported' | 'invalid-zip' | 'missing-zip'
export class LocationError extends Error {
  constructor(public code: LocationErrorCode, message: string) { super(message); this.name = 'LocationError' }
}
export interface LocationProvider {
  /** Must only be called after an explicit user action. */
  getLocation(input?: { zipCode?: string }): Promise<UserLocation>
}
/** Browser coordinates are rounded to ~1 km before leaving the provider; exact values are never stored or shown. */
export const roundCoord = (n: number) => Math.round(n * 100) / 100

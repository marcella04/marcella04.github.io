import type { UserLocation } from '../../types'
import type { LocationProvider } from './LocationProvider'

/** Fixed demo location for development and tests. */
export class MockLocationProvider implements LocationProvider {
  async getLocation(): Promise<UserLocation> {
    return { latitude: 39.5, longitude: -98.35, source: 'mock', updatedAt: new Date().toISOString() }
  }
}

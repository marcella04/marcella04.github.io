import type { UserLocation } from '../../types'
import { LocationError, type LocationProvider } from './LocationProvider'

/**
 * DEMO ONLY: no geocoder is configured, so a valid 5-digit ZIP maps to a coarse regional
 * centre by its first digit. This is NOT an accurate ZIP lookup. A production build should call
 * a server-side geocoding endpoint (see README → "ZIP-code geocoder").
 */
const REGION_CENTRES: Record<string, [number, number]> = {
  '0': [42.4, -71.6], '1': [41.0, -74.5], '2': [38.9, -77.0], '3': [33.5, -84.4], '4': [39.8, -85.0],
  '5': [43.0, -93.0], '6': [40.5, -90.0], '7': [32.5, -97.0], '8': [39.7, -105.0], '9': [37.0, -120.0],
}
export const isValidZip = (z: string) => /^\d{5}$/.test(z.trim())

export class ZipCodeLocationProvider implements LocationProvider {
  async getLocation(input?: { zipCode?: string }): Promise<UserLocation> {
    const zip = (input?.zipCode ?? '').trim()
    if (!zip) throw new LocationError('missing-zip', 'Enter a ZIP code.')
    if (!isValidZip(zip)) throw new LocationError('invalid-zip', 'Enter a valid 5-digit ZIP code.')
    const [latitude, longitude] = REGION_CENTRES[zip[0]]
    return { latitude, longitude, source: 'zip-demo', zipCode: zip, updatedAt: new Date().toISOString() }
  }
}

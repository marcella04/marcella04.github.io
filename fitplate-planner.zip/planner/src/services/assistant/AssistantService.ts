import type { MealType } from '../../types'

/**
 * Optional assistant boundary. The app works without it (DisabledAssistant).
 * An assistant may ONLY translate language into these structured actions; the deterministic engine
 * validates and executes them, so allergies, nutrition, prices, stores and distances can never be invented.
 */
export type AssistantAction =
  | { type: 'exclude-ingredient'; ingredient: string; date?: string }
  | { type: 'set-max-meal-price'; slot: MealType; date?: string; maxPrice: number }
  | { type: 'request-diet'; diet: 'vegetarian' | 'vegan' | 'pescatarian'; date: string }
  | { type: 'mark-eating-out'; date: string; slot: MealType }
  | { type: 'compare-stores'; mealId: string }
  | { type: 'set-max-distance'; miles: number }

export interface AssistantService {
  readonly enabled: boolean
  interpret(text: string): Promise<AssistantAction[]>
}
export class DisabledAssistant implements AssistantService {
  readonly enabled = false
  async interpret(): Promise<AssistantAction[]> { return [] }
}
/** Rejects malformed or out-of-range actions. Safety rules are never overridable here. */
export function validateAction(a: AssistantAction): boolean {
  switch (a.type) {
    case 'set-max-meal-price': return a.maxPrice > 0 && a.maxPrice < 500
    case 'set-max-distance': return a.miles > 0 && a.miles <= 50
    case 'exclude-ingredient': return a.ingredient.trim().length > 0
    default: return true
  }
}
export const assistant: AssistantService = new DisabledAssistant()

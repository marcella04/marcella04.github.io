import type { GroceryPrice, Store } from '../../types'
import { ProviderNotConfiguredError, type PriceRequest, type PricingProvider } from './PricingProvider'

/**
 * PLACEHOLDER ADAPTER for a live retailer integration (e.g. Kroger's developer API).
 *
 * Retailer credentials (client ID/secret, OAuth tokens) MUST NOT exist in this browser bundle.
 * A real implementation lives on a server: implement POST /api/prices/compare there, authenticate
 * with the retailer using server-side secrets, normalise results into `GroceryPrice` with
 * priceType 'live' and a genuine `retrievedAt`, and have this class call YOUR backend.
 *
 * Until a backend URL is configured this provider reports unsupported and makes no network calls.
 */
export class KrogerPricingProvider implements PricingProvider {
  readonly id = 'kroger-backend'
  constructor(private backendBaseUrl?: string) {}
  supports(store: Store) { return !!this.backendBaseUrl && store.chain.toLowerCase() === 'kroger' && store.dataSource === 'live' }
  async getPrices(_req: PriceRequest): Promise<GroceryPrice[]> {
    void _req
    throw new ProviderNotConfiguredError('Live retailer pricing requires a configured server-side API. See README → "Add a retailer pricing provider".')
  }
}

import type { GroceryPrice, Store } from '../../types'
import { KrogerPricingProvider } from './KrogerPricingProvider'
import { MockPricingProvider } from './MockPricingProvider'
import type { PricingProvider } from './PricingProvider'
import { UnsupportedStoreProvider } from './UnsupportedStoreProvider'

export class PricingService {
  constructor(private providers: PricingProvider[] = [new MockPricingProvider(), new KrogerPricingProvider(), new UnsupportedStoreProvider()]) {}
  async getPrices(stores: Store[], ingredientIds: string[] = []): Promise<GroceryPrice[]> {
    const groups = new Map<PricingProvider, Store[]>()
    for (const s of stores) {
      const p = this.providers.find(x => x.supports(s))!
      groups.set(p, [...(groups.get(p) ?? []), s])
    }
    const results = await Promise.all([...groups].map(async ([p, ss]) => {
      try { return await p.getPrices({ stores: ss, ingredientIds }) } catch { return [] as GroceryPrice[] }
    }))
    return results.flat()
  }
}
export const pricingService = new PricingService()

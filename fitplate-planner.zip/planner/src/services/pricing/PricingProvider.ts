import type { GroceryPrice, Store } from '../../types'

export interface PriceRequest { stores: Store[]; ingredientIds: string[] }
export interface PricingProvider {
  readonly id: string
  /** Whether this provider can price the given store (chain support + configuration). */
  supports(store: Store): boolean
  getPrices(req: PriceRequest): Promise<GroceryPrice[]>
}
export class ProviderNotConfiguredError extends Error {
  constructor(message: string) { super(message); this.name = 'ProviderNotConfiguredError' }
}

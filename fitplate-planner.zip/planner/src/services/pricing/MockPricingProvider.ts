import type { GroceryPrice, Store, StoreProduct } from '../../types'
import { storeProducts } from '../../data/products'
import { convert } from '../../engine/unitConversion'
import type { PriceRequest, PricingProvider } from './PricingProvider'

const toBaseUnit = (p: StoreProduct): number | undefined => {
  const base = p.packageUnit === 'lb' || p.packageUnit === 'oz' || p.packageUnit === 'g' || p.packageUnit === 'kg' ? 'oz' : undefined
  return base ? (convert(p.packageQuantity, p.packageUnit, 'oz') ?? undefined) : undefined
}
/** Serves SAMPLE prices from src/data/products.ts. Never labelled live; no retrieval timestamps are invented. */
export class MockPricingProvider implements PricingProvider {
  readonly id = 'mock-sample'
  supports(store: Store) { return store.dataSource === 'demo' && store.supportedPricing }
  async getPrices({ stores, ingredientIds }: PriceRequest): Promise<GroceryPrice[]> {
    const ids = new Set(stores.map(s => s.id)), wanted = new Set(ingredientIds)
    return storeProducts.filter(p => ids.has(p.storeId) && (wanted.size === 0 || wanted.has(p.ingredientId))).map(p => {
      const baseOz = toBaseUnit(p)
      return {
        ingredientId: p.ingredientId, productId: p.id, productName: p.productName, brand: p.brand, storeId: p.storeId,
        regularPrice: p.regularPrice, salePrice: p.salePrice, currency: p.currency, packageQuantity: p.packageQuantity, packageUnit: p.packageUnit,
        calculatedPricePerBaseUnit: baseOz ? (p.salePrice ?? p.regularPrice) / baseOz : undefined,
        availability: p.availability, retrievedAt: undefined, priceType: p.priceType, source: p.dataSource,
      }
    })
  }
}

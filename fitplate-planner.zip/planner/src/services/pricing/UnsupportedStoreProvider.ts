import type { GroceryPrice, Store } from '../../types'
import type { PriceRequest, PricingProvider } from './PricingProvider'

/** Fallback for stores without pricing support: returns no prices rather than guessing. */
export class UnsupportedStoreProvider implements PricingProvider {
  readonly id = 'unsupported'
  supports(_store: Store) { void _store; return true }
  async getPrices(_req: PriceRequest): Promise<GroceryPrice[]> { void _req; return [] }
}

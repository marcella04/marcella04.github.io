import type {
  CompletedMeal, CompletedWorkout, LocationPreference, UserProfile, WeeklyPlan, WeightEntry,
} from '../../types'

export interface ShoppingListState { removed: string[]; checked: string[] }
/** Everything persisted by the app. Replace the implementation (e.g. Supabase) without touching components. */
export interface StorageSchema {
  userProfile: UserProfile | null
  currentLocationPreference: LocationPreference
  weeklyPlans: Record<string, WeeklyPlan>
  weeklyShoppingLists: Record<string, ShoppingListState>
  favorites: string[]
  completedMeals: CompletedMeal[]
  completedWorkouts: CompletedWorkout[]
  weightHistory: WeightEntry[]
  selectedStores: Record<string, string>
  alreadyOwnedIngredients: string[]
}
export type StorageKey = keyof StorageSchema

export interface StorageService {
  get<K extends StorageKey>(key: K): StorageSchema[K]
  set<K extends StorageKey>(key: K, value: StorageSchema[K]): void
  remove(key: StorageKey): void
  clearAll(): void
}

export const storageDefaults: StorageSchema = {
  userProfile: null, currentLocationPreference: { mode: 'unset' }, weeklyPlans: {}, weeklyShoppingLists: {},
  favorites: [], completedMeals: [], completedWorkouts: [], weightHistory: [], selectedStores: {}, alreadyOwnedIngredients: [],
}
const PREFIX = 'fitplate:v1:'

export class LocalStorageService implements StorageService {
  get<K extends StorageKey>(key: K): StorageSchema[K] {
    try {
      const raw = localStorage.getItem(PREFIX + key)
      return raw === null ? structuredClone(storageDefaults[key]) : (JSON.parse(raw) as StorageSchema[K])
    } catch { return structuredClone(storageDefaults[key]) }
  }
  set<K extends StorageKey>(key: K, value: StorageSchema[K]): void {
    try { localStorage.setItem(PREFIX + key, JSON.stringify(value)) } catch { /* quota or private mode: ignore */ }
  }
  remove(key: StorageKey): void { try { localStorage.removeItem(PREFIX + key) } catch { /* ignore */ } }
  clearAll(): void {
    try { Object.keys(localStorage).filter(k => k.startsWith(PREFIX)).forEach(k => localStorage.removeItem(k)) } catch { /* ignore */ }
  }
}
export const storage: StorageService = new LocalStorageService()

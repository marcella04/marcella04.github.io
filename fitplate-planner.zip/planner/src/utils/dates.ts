export const iso = (d: Date) => {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}
export const parseIso = (s: string) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d) }
export function mondayOf(d: Date): string {
  const x = new Date(d.getFullYear(), d.getMonth(), d.getDate())
  const dow = (x.getDay() + 6) % 7
  x.setDate(x.getDate() - dow)
  return iso(x)
}
export function addDays(s: string, n: number): string { const d = parseIso(s); d.setDate(d.getDate() + n); return iso(d) }
export const weekDates = (weekStart: string) => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))
export const dayName = (s: string, long = false) => parseIso(s).toLocaleDateString('en-US', { weekday: long ? 'long' : 'short' })
export const dayNum = (s: string) => parseIso(s).getDate()
export const weekLabel = (ws: string) => {
  const a = parseIso(ws), b = parseIso(addDays(ws, 6))
  const f = (d: Date) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  return `${f(a)} – ${f(b)}`
}

export const money = (n: number) => `$${n.toFixed(2)}`
export const round1 = (n: number) => Math.round(n * 10) / 10

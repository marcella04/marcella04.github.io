// @vitest-environment jsdom
import { describe, expect, it, beforeEach } from 'vitest'
import { render, screen, within, cleanup } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import App from './App'
import { AppProvider } from './state/AppContext'

const mount = () => render(<MemoryRouter><AppProvider><App /></AppProvider></MemoryRouter>)
beforeEach(() => { cleanup(); localStorage.clear() })

describe('app workflows (sample data)', () => {
  it('onboarding → plan → details → swap → compare → shopping → progress → profile', async () => {
    const user = userEvent.setup()
    mount()
    await user.click(await screen.findByRole('button', { name: /save and build my week/i }))
    expect(await screen.findByRole('heading', { name: 'My Plan' })).toBeTruthy()
    expect(screen.getAllByRole('article').length).toBe(7)
    expect(screen.getAllByText(/Lunch/).length).toBeGreaterThan(0)

    // location prompt: nothing requested automatically; choose ZIP
    await user.click(screen.getByRole('button', { name: 'Enter ZIP Code' }))
    await user.type(screen.getByLabelText('ZIP code'), '12')
    await user.click(screen.getByRole('button', { name: 'Use ZIP' }))
    expect((await screen.findByRole('alert')).textContent).toMatch(/valid 5-digit/)
    await user.clear(screen.getByLabelText('ZIP code')); await user.type(screen.getByLabelText('ZIP code'), '90210')
    await user.click(screen.getByRole('button', { name: 'Use ZIP' }))

    // meal details
    const first = screen.getAllByRole('article')[0]
    await user.click(within(first).getAllByRole('button', { name: 'Details' })[0])
    const dlg = await screen.findByRole('dialog')
    await user.click(within(dlg).getByRole('button', { name: 'Mark as Eaten' }))
    expect(within(dlg).getByRole('button', { name: /Eaten \(undo\)/ })).toBeTruthy()
    await user.click(within(dlg).getByRole('button', { name: 'Swap Meal' }))
    const swap = await screen.findByRole('dialog')
    const use = within(swap).queryAllByRole('button', { name: 'Use this' })
    expect(use.length).toBeGreaterThan(0)
    await user.click(use[0])

    // compare stores
    await user.click(within(screen.getAllByRole('article')[1]).getAllByRole('button', { name: 'Compare Stores' })[0])
    const cmp = await screen.findByRole('dialog')
    expect((await within(cmp).findAllByText(/Demo Market/)).length).toBeGreaterThan(0)
    expect(within(cmp).queryByText(/^Live price/)).toBeNull()
    await user.keyboard('{Escape}')

    // complete workout
    const wk = within(screen.getAllByRole('article')[0]).getByRole('button', { name: /Complete|Undo/ })
    await user.click(wk)

    // shopping
    await user.click(screen.getByRole('link', { name: 'Shopping' }))
    expect(await screen.findByRole('heading', { name: 'Shopping' })).toBeTruthy()
    expect(await screen.findByText('Weekly Grocery Estimate')).toBeTruthy()
    expect(await screen.findByText(/Split-store option/)).toBeTruthy()
    await user.click(screen.getAllByRole('button', { name: 'I have this' })[0])

    // progress
    await user.click(screen.getByRole('link', { name: 'Progress' }))
    await user.type(await screen.findByLabelText('Weight (lb)'), '178.5')
    await user.click(screen.getByRole('button', { name: 'Add entry' }))
    expect(await screen.findByText('178.5 lb')).toBeTruthy()

    // profile + remove location
    await user.click(screen.getByRole('link', { name: 'Profile' }))
    await user.click(await screen.findByRole('button', { name: 'Remove saved location' }))
    expect(screen.getByText('No location set.')).toBeTruthy()
    expect(JSON.parse(localStorage.getItem('fitplate:v1:currentLocationPreference')!).mode).toBe('unset')
  })
})

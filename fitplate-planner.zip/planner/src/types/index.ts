export type Unit = 'oz' | 'lb' | 'g' | 'kg' | 'tsp' | 'tbsp' | 'cup' | 'ml' | 'l' | 'count' | 'package' | 'can'
export type MealType = 'lunch' | 'dinner'
export type DietPref = 'omnivore' | 'pescatarian' | 'vegetarian' | 'vegan'
export type Allergen = 'peanut' | 'tree-nut' | 'dairy' | 'egg' | 'gluten' | 'soy' | 'fish' | 'shellfish' | 'sesame'
export type MealCategory =
  | 'high-protein' | 'budget' | 'vegetarian' | 'vegan' | 'pescatarian' | 'quick'
  | 'no-cook' | 'meal-prep' | 'restaurant' | 'grocery-prepared'
export type PriceType = 'estimated' | 'sample' | 'live'
export type DataSource = 'demo' | 'live'

export interface IngredientCatalogItem {
  id: string; name: string; category: string; defaultUnit: Unit; aliases: string[]; allergenTags: Allergen[]
  pantryStaple?: boolean
}
export interface IngredientRequirement { ingredientId: string; name: string; quantity: number; unit: Unit }
export interface Meal {
  id: string; name: string; mealType: MealType[]; servings: number
  calories: number; protein: number; carbs: number; fat: number
  estimatedCostPerServing: number; prepMinutes: number
  ingredients: IngredientRequirement[]; instructions: string[]
  dietTags: DietPref[]; categories: MealCategory[]; allergens: Allergen[]
  suggestedStoreChains: string[]; restaurant?: string; imagePlaceholder: string
}
export interface StoreProduct {
  id: string; storeId: string; ingredientId: string; productName: string; brand?: string
  packageQuantity: number; packageUnit: Unit; regularPrice: number; salePrice?: number
  currency: string; availability: 'in-stock' | 'out-of-stock' | 'unknown'
  retrievedAt?: string; priceType: PriceType; dataSource: string
}
export interface Store {
  id: string; name: string; chain: string; address: string; latitude: number; longitude: number
  distanceMiles: number; supportedPricing: boolean; dataSource: DataSource
}
export interface GroceryPrice {
  ingredientId: string; productId: string; productName: string; brand?: string; storeId: string
  regularPrice: number; salePrice?: number; currency: string; packageQuantity: number; packageUnit: string
  calculatedPricePerBaseUnit?: number; availability: 'in-stock' | 'out-of-stock' | 'unknown'
  retrievedAt?: string; priceType: PriceType; source: string
}
export interface Coords { latitude: number; longitude: number }
export interface UserLocation extends Coords {
  source: 'browser' | 'zip-demo' | 'mock'; accuracyMeters?: number; zipCode?: string; updatedAt: string
}
export type LocationMode = 'unset' | 'browser' | 'zip' | 'declined' | 'disabled'
export interface LocationPreference { mode: LocationMode; zipCode?: string; location?: UserLocation }

export type Sex = 'female' | 'male'
export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active'
export type FitnessLevel = 'beginner' | 'intermediate' | 'advanced'
export type Equipment = 'none' | 'dumbbells' | 'bands' | 'gym'
export type CookingPref = 'no-cook' | 'minimal' | 'enjoy-cooking'
export type StorePriority = 'lowest-price' | 'closest' | 'best-value'
export interface UserProfile {
  onboarded: boolean
  age: number; sex: Sex; heightIn: number; weightLb: number; goalWeightLb: number
  activity: ActivityLevel; diet: DietPref; allergies: Allergen[]; dislikedFoods: string
  dailyFoodBudget: number; weeklyGroceryBudget: number; maxPricePerMeal: number
  cooking: CookingPref; maxPrepMinutes: number
  fitness: FitnessLevel; equipment: Equipment[]; workoutMinutes: number; workoutDaysPerWeek: number
  storeRadiusMiles: number; storePriority: StorePriority
}

export type WorkoutCategory = 'cardio' | 'full-body' | 'upper' | 'lower' | 'mobility' | 'rest'
export interface Exercise { name: string; sets?: number; reps?: string; seconds?: number; instructions: string }
export interface Workout {
  id: string; name: string; difficulty: FitnessLevel; durationMin: number; equipment: Equipment[]
  category: WorkoutCategory; exercises: Exercise[]; description: string
}

export interface PlanDay { date: string; lunchId?: string; dinnerId?: string; workoutId?: string }
export interface WeeklyPlan { weekStart: string; days: PlanDay[]; warnings: string[]; generatedAt: string }
export interface ShoppingItem {
  key: string; ingredientId: string; name: string; quantity: number; unit: Unit; category: string; pantry: boolean
}
export interface WeightEntry { date: string; weightLb: number }
export interface CompletedWorkout { date: string; workoutId: string }
export interface CompletedMeal { date: string; slot: MealType; mealId: string }

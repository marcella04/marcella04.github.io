import type { GroceryPrice, IngredientRequirement, Store } from './index'
/** Future backend contract (documented in README). */
// GET /api/stores/nearby?lat=&lng=&radiusMiles=&chains=
export interface NearbyStoresResponse { stores: Store[]; provider: string; generatedAt: string }
// POST /api/prices/compare
export interface ComparePricesRequest { storeIds: string[]; requirements: IngredientRequirement[]; servings: number }
export interface ComparePricesResponse { prices: GroceryPrice[]; provider: string }
// POST /api/shopping-list/compare
export interface CompareShoppingListRequest { storeIds: string[]; items: IngredientRequirement[]; mode: 'single' | 'split' }
export interface CompareShoppingListResponse { prices: GroceryPrice[]; provider: string }

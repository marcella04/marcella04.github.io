import { useState } from 'react'
import type { IngredientRequirement } from '../../types'
import { useApp } from '../../state/AppContext'
import { useComparison } from '../../hooks/useComparison'
import { sortComparisons, type SortKey, type StoreComparison } from '../../engine/storeComparison'
import { Badge, Button, Card, CoverageIndicator, DistanceLabel, EmptyState, ErrorState, LoadingState, Notice, PriceLabel } from '../UI'
import { LocationPrompt } from '../Location/LocationControls'
import { money } from '../../utils/format'

const SORTS: [SortKey, string][] = [['bestValue', 'Best Value'], ['checkout', 'Lowest Checkout Cost'], ['perServing', 'Lowest Cost Per Serving'], ['closest', 'Closest']]
const REASON = { 'no-product': 'no matching product', 'out-of-stock': 'out of stock', 'unit-incompatible': 'units cannot be compared' } as const

interface Props { requirements: IngredientRequirement[]; servings: number; perLabel: string; weekly?: boolean }

export function StoreComparisonView({ requirements, servings, perLabel, weekly }: Props) {
  const app = useApp()
  const [sort, setSort] = useState<SortKey>(app.profile?.storePriority === 'closest' ? 'closest' : app.profile?.storePriority === 'lowest-price' ? 'checkout' : 'bestValue')
  const cmp = useComparison(requirements, servings)
  const { nearby } = app

  if (!app.localOn) return (
    <div className="space-y-3">
      <EmptyState title="Local store comparison is off">Share a location or ZIP code to compare supported nearby stores. Meal plans work without it.</EmptyState>
      <LocationPrompt />
    </div>
  )
  if (nearby.status === 'loading' || nearby.status === 'idle') return <LoadingState label="Finding nearby stores…" />
  if (nearby.status === 'error') return <ErrorState message={nearby.error ?? 'Could not load stores.'} onRetry={app.retryNearby} />
  if (!requirements.length) return <EmptyState title="Nothing to compare">This item has no grocery ingredients (for example, a restaurant meal).</EmptyState>
  if (!cmp) return null
  const { result, split } = cmp
  const rows = sortComparisons(result.rows, sort)
  if (!result.rows.length) return <EmptyState title="No supported stores nearby">No stores with supported pricing were found within {app.radius} miles. Try a larger radius in Profile.</EmptyState>

  return (
    <div className="space-y-3">
      <Notice>Demo stores and sample prices — not real locations or live prices. Distances are approximate straight-line miles, not driving distance.</Notice>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm font-semibold text-teal-900">{result.headline}</p>
        <div>
          <label htmlFor="sort" className="mr-2 text-sm">Sort by</label>
          <select id="sort" value={sort} onChange={e => setSort(e.target.value as SortKey)} className="rounded-lg border border-stone-300 px-2 py-1 text-sm">
            {SORTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </div>
      </div>
      {!result.confident && <Notice tone="warning">Some stores have incomplete pricing coverage, so this is not a definitive cheapest-store ranking. Compare coverage and missing items below.</Notice>}
      <ul className="space-y-3">
        {rows.map((r, i) => <StoreCard key={r.store.id} r={r} rank={i + 1} isBest={r === result.best} perLabel={perLabel}
          selected={weekly && app.selectedStores[app.weekStart] === r.store.id} onSelect={weekly ? () => app.selectStore(r.store.id) : undefined} />)}
      </ul>
      {result.unsupportedStores.length > 0 && (
        <p className="text-xs text-stone-600">Nearby without supported pricing (distance only): {result.unsupportedStores.map(s => `${s.name} (≈${s.distanceMiles.toFixed(1)} mi)`).join(', ')}.</p>
      )}
      {weekly && (
        <Card className="bg-stone-50">
          <h3 className="font-semibold">Split-store option</h3>
          <p className="mt-1 text-sm">{split.message}</p>
          <p className="mt-1 text-xs text-stone-600">Would use {split.storesUsed.length} store(s): {split.storesUsed.map(s => s.name).join(', ') || '—'} · estimated total {money(split.total)} · {split.coveredCount} of {split.totalCount} items priced</p>
          {split.missing.length > 0 && <p className="text-xs text-stone-600">Missing everywhere: {split.missing.map(m => m.name).join(', ')}</p>}
        </Card>
      )}
    </div>
  )
}

function StoreCard({ r, rank, isBest, perLabel, selected, onSelect }: { r: StoreComparison; rank: number; isBest: boolean; perLabel: string; selected?: boolean; onSelect?: () => void }) {
  const noData = r.pricedIngredientCount === 0
  return (
    <li><Card className={isBest ? 'border-teal-500 ring-1 ring-teal-500' : ''}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h3 className="font-semibold">{noData ? '' : `${rank}. `}{r.store.name}</h3>
          <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-stone-600"><span>{r.store.chain}</span><DistanceLabel miles={r.distanceMiles} />{r.store.dataSource === 'demo' && <Badge tone="violet">Demo store</Badge>}</div>
        </div>
        <div className="flex flex-wrap gap-1">{isBest && <Badge tone="teal">Best value</Badge>}{!noData && <PriceLabel type={r.priceType} retrievedAt={r.latestRetrievedAt} />}</div>
      </div>
      {noData ? <p className="mt-2 text-sm text-stone-600">No usable price data for this store.</p> : (
        <>
          <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
            <div><dt className="text-xs text-stone-500">Package checkout</dt><dd className="font-semibold">{money(r.totalCheckoutCost)}</dd><dd className="text-[11px] text-stone-500">whole packages</dd></div>
            <div><dt className="text-xs text-stone-500">Ingredient usage</dt><dd className="font-semibold">{money(r.estimatedUsageCost)}</dd><dd className="text-[11px] text-stone-500">only what is used</dd></div>
            <div><dt className="text-xs text-stone-500">Cost {perLabel}</dt><dd className="font-semibold">{money(r.mealCostPerServing)}</dd><dd className="text-[11px] text-stone-500">on priced items</dd></div>
            <div><dt className="text-xs text-stone-500">Best-value score</dt><dd className="font-semibold">{r.score}/100</dd></div>
          </dl>
          <div className="mt-3"><CoverageIndicator percent={r.coveragePercent} priced={r.pricedIngredientCount} total={r.totalIngredientCount} /></div>
        </>
      )}
      {r.missingIngredients.length > 0 && <p className="mt-2 text-xs text-red-800">⚠ Not priced: {r.missingIngredients.map(m => `${m.name} (${REASON[m.reason]})`).join(', ')}. These are not counted as free.</p>}
      {r.uncertainMatches.length > 0 && <p className="mt-1 text-xs text-stone-700">△ Uncertain match (excluded): {r.uncertainMatches.map(m => `${m.name} ≈ ${m.productName}`).join(', ')}</p>}
      <p className="mt-2 text-xs text-stone-600">{r.explanation}</p>
      {onSelect && !noData && <Button size="sm" variant="teal" className="mt-2" onClick={onSelect} aria-pressed={selected}>{selected ? '✓ Selected store' : 'Shop at this store'}</Button>}
    </Card></li>
  )
}

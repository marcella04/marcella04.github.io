import { useState, type ReactNode } from 'react'
import type { Allergen, Equipment, UserProfile } from '../../types'
import { Button, Card, Notice } from '../UI'
import { calcTargets, validateProfile } from '../../engine/nutritionCalculator'

export const defaultProfile: UserProfile = {
  onboarded: false, age: 35, sex: 'female', heightIn: 66, weightLb: 180, goalWeightLb: 160, activity: 'light', diet: 'omnivore',
  allergies: [], dislikedFoods: '', dailyFoodBudget: 20, weeklyGroceryBudget: 120, maxPricePerMeal: 8, cooking: 'minimal', maxPrepMinutes: 30,
  fitness: 'beginner', equipment: ['none'], workoutMinutes: 30, workoutDaysPerWeek: 3, storeRadiusMiles: 5, storePriority: 'best-value',
}
const ALLERGENS: Allergen[] = ['peanut', 'tree-nut', 'dairy', 'egg', 'gluten', 'soy', 'fish', 'shellfish', 'sesame']
const EQUIPMENT: { id: Equipment; label: string }[] = [
  { id: 'none', label: 'No equipment' }, { id: 'dumbbells', label: 'Dumbbells' }, { id: 'bands', label: 'Resistance bands' }, { id: 'gym', label: 'Gym access' },
]
const input = 'w-full rounded-lg border border-stone-300 bg-white px-3 py-2 text-sm'

function Field({ id, label, children, hint }: { id: string; label: string; children: ReactNode; hint?: string }) {
  return <div><label htmlFor={id} className="mb-1 block text-sm font-medium">{label}</label>{children}{hint && <p className="mt-0.5 text-xs text-stone-500">{hint}</p>}</div>
}
function Num({ id, label, value, onChange, step = 1, hint }: { id: string; label: string; value: number; onChange: (n: number) => void; step?: number; hint?: string }) {
  return <Field id={id} label={label} hint={hint}><input id={id} type="number" step={step} className={input} value={Number.isFinite(value) ? value : ''} onChange={e => onChange(e.target.value === '' ? NaN : Number(e.target.value))} /></Field>
}
function Sel<T extends string>({ id, label, value, onChange, options }: { id: string; label: string; value: T; onChange: (v: T) => void; options: [T, string][] }) {
  return <Field id={id} label={label}><select id={id} className={input} value={value} onChange={e => onChange(e.target.value as T)}>{options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
}
const toggle = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter(x => x !== v) : [...arr, v])

export function ProfileForm({ initial, submitLabel, onSubmit }: { initial: UserProfile; submitLabel: string; onSubmit: (p: UserProfile) => void }) {
  const [p, setP] = useState<UserProfile>(initial)
  const [errors, setErrors] = useState<string[]>([])
  const set = <K extends keyof UserProfile>(k: K, v: UserProfile[K]) => setP(prev => ({ ...prev, [k]: v }))
  const check = validateProfile(p)
  const targets = check.errors.length ? null : calcTargets(p)
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (check.errors.length || [p.dailyFoodBudget, p.weeklyGroceryBudget, p.maxPricePerMeal, p.maxPrepMinutes, p.workoutMinutes].some(n => !Number.isFinite(n))) {
      setErrors(check.errors.length ? check.errors : ['Please fill in every number field.']); window.scrollTo({ top: 0, behavior: 'smooth' }); return
    }
    setErrors([]); onSubmit({ ...p, onboarded: true })
  }
  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      {errors.length > 0 && <div role="alert" className="rounded-xl border border-red-300 bg-red-50 p-3 text-sm text-red-800"><ul className="list-disc pl-5">{errors.map(e => <li key={e}>{e}</li>)}</ul></div>}
      <Card><h2 className="mb-3 font-semibold text-emerald-900">About you (for calorie estimates)</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          <Num id="age" label="Age" value={p.age} onChange={v => set('age', v)} />
          <Sel id="sex" label="Sex (for the calorie formula)" value={p.sex} onChange={v => set('sex', v)} options={[['female', 'Female'], ['male', 'Male']]} />
          <Num id="height" label="Height (inches)" value={p.heightIn} onChange={v => set('heightIn', v)} />
          <Num id="weight" label="Current weight (lb)" value={p.weightLb} onChange={v => set('weightLb', v)} />
          <Num id="goal" label="Goal weight (lb)" value={p.goalWeightLb} onChange={v => set('goalWeightLb', v)} />
          <Sel id="activity" label="Activity level" value={p.activity} onChange={v => set('activity', v)} options={[['sedentary', 'Mostly sitting'], ['light', 'Lightly active'], ['moderate', 'Moderately active'], ['active', 'Very active']]} />
        </div>
        {targets && <p className="mt-3 text-sm text-stone-700">Estimated daily target: <strong>{targets.dailyTarget} kcal</strong> (lunch ≈ {targets.lunch}, dinner ≈ {targets.dinner}). {targets.note} These are estimates, not medical advice.</p>}
        {check.warnings.map(w => <div key={w} className="mt-2"><Notice tone="warning">{w}</Notice></div>)}
      </Card>
      <Card><h2 className="mb-3 font-semibold text-emerald-900">Food</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          <Sel id="diet" label="Dietary preference" value={p.diet} onChange={v => set('diet', v)} options={[['omnivore', 'No restriction'], ['pescatarian', 'Pescatarian'], ['vegetarian', 'Vegetarian'], ['vegan', 'Vegan']]} />
          <Sel id="cooking" label="Cooking preference" value={p.cooking} onChange={v => set('cooking', v)} options={[['no-cook', 'No cooking'], ['minimal', 'Minimal cooking'], ['enjoy-cooking', 'I enjoy cooking']]} />
          <Num id="prep" label="Max prep time (min)" value={p.maxPrepMinutes} onChange={v => set('maxPrepMinutes', v)} />
          <Num id="daily" label="Daily food budget ($)" value={p.dailyFoodBudget} onChange={v => set('dailyFoodBudget', v)} />
          <Num id="weekly" label="Weekly grocery budget ($)" value={p.weeklyGroceryBudget} onChange={v => set('weeklyGroceryBudget', v)} />
          <Num id="meal" label="Max price per meal ($)" value={p.maxPricePerMeal} onChange={v => set('maxPricePerMeal', v)} step={0.5} />
        </div>
        <fieldset className="mt-3"><legend className="mb-1 text-sm font-medium">Allergies and restrictions (always excluded)</legend>
          <div className="flex flex-wrap gap-2">{ALLERGENS.map(a => (
            <label key={a} className="flex items-center gap-1.5 rounded-lg border border-stone-300 bg-white px-2.5 py-1 text-sm">
              <input type="checkbox" checked={p.allergies.includes(a)} onChange={() => set('allergies', toggle(p.allergies, a))} />{a.replace('-', ' ')}
            </label>))}</div>
        </fieldset>
        <div className="mt-3"><Field id="disliked" label="Foods you dislike (comma separated)"><input id="disliked" className={input} value={p.dislikedFoods} onChange={e => set('dislikedFoods', e.target.value)} placeholder="e.g. tofu, cilantro" /></Field></div>
      </Card>
      <Card><h2 className="mb-3 font-semibold text-blue-900">Fitness</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          <Sel id="fitness" label="Fitness level" value={p.fitness} onChange={v => set('fitness', v)} options={[['beginner', 'Beginner'], ['intermediate', 'Intermediate'], ['advanced', 'Advanced']]} />
          <Num id="wmin" label="Preferred workout length (min)" value={p.workoutMinutes} onChange={v => set('workoutMinutes', v)} step={5} />
          <Sel id="wdays" label="Active days per week" value={String(p.workoutDaysPerWeek) as '3'} onChange={v => set('workoutDaysPerWeek', Number(v))} options={[['2', '2'], ['3', '3'], ['4', '4'], ['5', '5'], ['6', '6']]} />
        </div>
        <fieldset className="mt-3"><legend className="mb-1 text-sm font-medium">Available equipment</legend>
          <div className="flex flex-wrap gap-2">{EQUIPMENT.map(e => (
            <label key={e.id} className="flex items-center gap-1.5 rounded-lg border border-stone-300 bg-white px-2.5 py-1 text-sm">
              <input type="checkbox" checked={p.equipment.includes(e.id)} onChange={() => set('equipment', toggle(p.equipment, e.id))} />{e.label}
            </label>))}</div>
        </fieldset>
      </Card>
      <Card><h2 className="mb-3 font-semibold text-teal-900">Stores</h2>
        <div className="grid gap-3 sm:grid-cols-3">
          <Num id="radius" label="Preferred store radius (miles)" value={p.storeRadiusMiles} onChange={v => set('storeRadiusMiles', v)} />
          <Sel id="priority" label="Store priority" value={p.storePriority} onChange={v => set('storePriority', v)} options={[['lowest-price', 'Lowest price'], ['closest', 'Closest store'], ['best-value', 'Best value']]} />
        </div>
      </Card>
      <Button type="submit" variant="primary">{submitLabel}</Button>
    </form>
  )
}

import { NavLink, Outlet } from 'react-router-dom'
import { Disclaimer } from './Disclaimer'

const links = [
  { to: '/', label: 'My Plan', end: true }, { to: '/shopping', label: 'Shopping' },
  { to: '/progress', label: 'Progress' }, { to: '/profile', label: 'Profile' },
]
export function Layout() {
  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:p-2">Skip to content</a>
      <header className="sticky top-0 z-40 border-b border-stone-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 py-2">
          <span className="text-lg font-bold text-emerald-800">🥗 FitPlate</span>
          <nav aria-label="Main" className="flex gap-1">
            {links.map(l => (
              <NavLink key={l.to} to={l.to} end={l.end}
                className={({ isActive }) => `rounded-lg px-3 py-1.5 text-sm font-medium ${isActive ? 'bg-emerald-100 text-emerald-900' : 'text-stone-700 hover:bg-stone-100'}`}>
                {l.label}
              </NavLink>
            ))}
          </nav>
        </div>
        <div className="bg-violet-50 px-4 py-1 text-center text-xs text-violet-900">Demo build: meals, nutrition, stores and prices are sample/estimated data, not live.</div>
      </header>
      <main id="main" className="mx-auto w-full max-w-7xl flex-1 px-4 py-5"><Outlet /></main>
      <footer className="border-t border-stone-200 bg-white px-4 py-4"><div className="mx-auto max-w-7xl"><Disclaimer /></div></footer>
    </div>
  )
}

export function Disclaimer() {
  return (
    <aside aria-label="Important information" className="text-xs leading-relaxed text-stone-600">
      <strong className="text-stone-800">Please note:</strong> Nutrition and calorie values are estimates. Store prices can change and the prices shown here are
      sample or estimated data. This application provides general planning information and is not medical advice. If you have a medical condition, are pregnant,
      have eating-disorder concerns, have an injury, or have other special circumstances, please seek guidance from a qualified professional before changing your diet or exercise.
    </aside>
  )
}

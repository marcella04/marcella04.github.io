import { useState } from 'react'
import { useApp } from '../../state/AppContext'
import { Button, Card, Notice } from '../UI'
import { isInaccurate } from '../../services/location/BrowserLocationProvider'

/** Permission prompt. Browser location is requested ONLY when "Use My Location" is clicked. */
export function LocationPrompt({ onDone }: { onDone?: () => void }) {
  const app = useApp()
  const [zip, setZip] = useState('')
  const [showZip, setShowZip] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const run = async (fn: () => Promise<{ ok: boolean; message?: string }>) => {
    setBusy(true); setError(''); const r = await fn(); setBusy(false)
    if (!r.ok) setError(r.message ?? 'Something went wrong.'); else onDone?.()
  }
  return (
    <Card className="border-teal-200 bg-teal-50/60">
      <h2 className="font-semibold text-teal-900">Use your location to find nearby grocery stores and compare supported prices?</h2>
      <p className="mt-1 text-sm text-teal-900/80">Location is used once, only to find stores near you. We don’t track you or keep history, and we never show exact coordinates.</p>
      <div className="mt-3 flex flex-wrap items-end gap-2">
        <Button variant="teal" disabled={busy} onClick={() => run(app.useBrowserLocation)}>{busy ? 'Locating…' : 'Use My Location'}</Button>
        <Button disabled={busy} onClick={() => setShowZip(s => !s)} aria-expanded={showZip}>Enter ZIP Code</Button>
        <Button variant="ghost" disabled={busy} onClick={() => { app.declineLocation(); onDone?.() }}>Not Now</Button>
      </div>
      {showZip && (
        <div className="mt-3 flex flex-wrap items-end gap-2">
          <div>
            <label htmlFor="zip-input" className="block text-sm font-medium">ZIP code</label>
            <input id="zip-input" inputMode="numeric" maxLength={5} value={zip} onChange={e => setZip(e.target.value.replace(/\D/g, ''))}
              onKeyDown={e => { if (e.key === 'Enter') run(() => app.useZip(zip)) }}
              className="w-28 rounded-lg border border-stone-300 px-3 py-2 text-sm" aria-describedby="zip-help" />
          </div>
          <Button variant="teal" disabled={busy} onClick={() => run(() => app.useZip(zip))}>Use ZIP</Button>
          <p id="zip-help" className="basis-full text-xs text-stone-600">Demo mode: ZIP codes map to a coarse sample area, not an exact geocode.</p>
        </div>
      )}
      {error && <div className="mt-3"><Notice tone="warning">{error}</Notice></div>}
    </Card>
  )
}

/** Shown on the Profile page: update, switch, remove, or disable local recommendations. */
export function LocationSettings() {
  const app = useApp()
  const pref = app.locationPref
  const [open, setOpen] = useState(false)
  const status =
    pref.mode === 'browser' ? 'Using your device location (approximate area saved).'
    : pref.mode === 'zip' ? `Using ZIP code ${pref.zipCode} (demo approximate area).`
    : pref.mode === 'disabled' ? 'Local recommendations are turned off.'
    : pref.mode === 'declined' ? 'You chose not to share a location.' : 'No location set.'
  return (
    <Card>
      <h2 className="font-semibold">Location & local stores</h2>
      <p className="mt-1 text-sm text-stone-700" role="status">{status}</p>
      {pref.location && isInaccurate(pref.location) && <p className="mt-1 text-sm text-red-700">⚠ Your location accuracy is low, so nearby distances may be off. Try a ZIP code.</p>}
      <div className="mt-3 flex flex-wrap gap-2">
        <Button variant="teal" onClick={() => setOpen(o => !o)} aria-expanded={open}>{pref.location ? 'Update location' : 'Set location'}</Button>
        {pref.mode === 'browser' && <Button onClick={() => setOpen(true)}>Switch to ZIP code</Button>}
        {pref.mode !== 'disabled' && <Button onClick={app.disableLocal}>Disable local recommendations</Button>}
        {(pref.location || pref.mode !== 'unset') && <Button variant="danger" onClick={app.removeLocationData}>Remove saved location</Button>}
      </div>
      {open && <div className="mt-3"><LocationPrompt onDone={() => setOpen(false)} /></div>}
    </Card>
  )
}

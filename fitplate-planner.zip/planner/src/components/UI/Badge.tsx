import type { ReactNode } from 'react'
type Tone = 'neutral' | 'green' | 'blue' | 'teal' | 'violet' | 'red'
const tones: Record<Tone, string> = {
  neutral: 'bg-stone-100 text-stone-700', green: 'bg-emerald-100 text-emerald-900', blue: 'bg-blue-100 text-blue-900',
  teal: 'bg-teal-100 text-teal-900', violet: 'bg-violet-100 text-violet-900', red: 'bg-red-100 text-red-800',
}
export function Badge({ tone = 'neutral', children }: { tone?: Tone; children: ReactNode }) {
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>
}

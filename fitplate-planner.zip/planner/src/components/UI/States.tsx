import type { ReactNode } from 'react'
import { Button } from './Button'

export function LoadingState({ label = 'Loading…' }: { label?: string }) {
  return <div role="status" className="flex items-center gap-2 p-4 text-sm text-stone-600"><span className="h-4 w-4 animate-spin rounded-full border-2 border-stone-300 border-t-teal-700" aria-hidden />{label}</div>
}
export function EmptyState({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="rounded-xl border border-dashed border-stone-300 bg-white/60 p-6 text-center">
      <h3 className="font-semibold text-stone-800">{title}</h3>
      {children && <p className="mx-auto mt-1 max-w-md text-sm text-stone-600">{children}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  )
}
export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div role="alert" className="rounded-xl border border-red-300 bg-red-50 p-4 text-sm text-red-800">
      <strong>Something went wrong.</strong> {message}
      {onRetry && <Button size="sm" variant="danger" className="ml-3" onClick={onRetry}>Try again</Button>}
    </div>
  )
}
export function Notice({ tone = 'info', children }: { tone?: 'info' | 'warning'; children: ReactNode }) {
  const c = tone === 'warning' ? 'border-red-300 bg-red-50 text-red-900' : 'border-violet-200 bg-violet-50 text-violet-900'
  return <div role={tone === 'warning' ? 'alert' : 'note'} className={`rounded-xl border p-3 text-sm ${c}`}>{tone === 'warning' && <span aria-hidden>⚠ </span>}{children}</div>
}

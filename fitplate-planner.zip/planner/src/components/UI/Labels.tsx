import type { PriceType } from '../../types'
import { Badge } from './Badge'
import { formatApproxMiles } from '../../engine/distanceCalculator'

const TEXT: Record<PriceType, string> = { estimated: 'Estimated price', sample: 'Sample price', live: 'Live price' }
/** "Live price" is only shown for genuinely live data, with its real retrieval time. */
export function PriceLabel({ type, retrievedAt }: { type: PriceType; retrievedAt?: string }) {
  const when = type === 'live' && retrievedAt ? ` · retrieved ${new Date(retrievedAt).toLocaleString()}` : ''
  return <Badge tone={type === 'live' ? 'teal' : 'violet'}>{TEXT[type]}{when}</Badge>
}
export function DistanceLabel({ miles }: { miles: number }) {
  return <span className="text-xs text-stone-600" title="Approximate straight-line distance, not driving distance">{formatApproxMiles(miles)}</span>
}
export function CoverageIndicator({ percent, priced, total }: { percent: number; priced: number; total: number }) {
  const full = percent >= 90
  return (
    <div className="min-w-[8rem]">
      <div className="flex items-center justify-between text-xs">
        <span className="font-medium">{full ? '✓ High coverage' : percent === 0 ? '✕ No data' : '△ Partial data'}</span>
        <span>{percent}%</span>
      </div>
      <div className="mt-1 h-1.5 overflow-hidden rounded bg-stone-200" role="img" aria-label={`${priced} of ${total} ingredients priced (${percent}%)`}>
        <div className="h-full bg-teal-600" style={{ width: `${percent}%` }} />
      </div>
      <div className="mt-0.5 text-[11px] text-stone-600">{priced} of {total} ingredients priced</div>
    </div>
  )
}

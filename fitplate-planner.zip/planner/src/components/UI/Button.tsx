import type { ButtonHTMLAttributes } from 'react'

type Variant = 'primary' | 'secondary' | 'ghost' | 'blue' | 'teal' | 'danger'
const styles: Record<Variant, string> = {
  primary: 'bg-emerald-700 text-white hover:bg-emerald-800 disabled:bg-emerald-300',
  blue: 'bg-blue-700 text-white hover:bg-blue-800 disabled:bg-blue-300',
  teal: 'bg-teal-700 text-white hover:bg-teal-800 disabled:bg-teal-300',
  secondary: 'bg-white text-stone-800 border border-stone-300 hover:bg-stone-100 disabled:text-stone-400',
  ghost: 'text-stone-700 hover:bg-stone-200/60 disabled:text-stone-400',
  danger: 'bg-white text-red-700 border border-red-300 hover:bg-red-50',
}
interface Props extends ButtonHTMLAttributes<HTMLButtonElement> { variant?: Variant; size?: 'sm' | 'md' }
export function Button({ variant = 'secondary', size = 'md', className = '', type = 'button', ...rest }: Props) {
  return (
    <button type={type} {...rest}
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg font-medium transition-colors disabled:cursor-not-allowed ${size === 'sm' ? 'px-2.5 py-1 text-xs' : 'px-4 py-2 text-sm'} ${styles[variant]} ${className}`} />
  )
}

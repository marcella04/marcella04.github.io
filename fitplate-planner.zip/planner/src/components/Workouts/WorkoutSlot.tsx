import type { Workout } from '../../types'
import { Badge, Button } from '../UI'

export function WorkoutSlot({ workout, done, onView, onComplete }: { workout?: Workout; done: boolean; onView: () => void; onComplete: () => void }) {
  if (!workout) return null
  const rest = workout.category === 'rest'
  return (
    <section aria-label={`Workout: ${workout.name}`} className="rounded-xl bg-blue-50/80 p-3">
      <div className="flex items-center justify-between"><h4 className="text-xs font-semibold uppercase tracking-wide text-blue-800">Workout</h4>{done && <Badge tone="blue">✓ Done</Badge>}</div>
      <p className="mt-1 text-sm font-semibold">{workout.name}</p>
      <p className="text-xs text-stone-700">{rest ? 'Recovery' : `${workout.durationMin} minutes · ${workout.difficulty}`}</p>
      <div className="mt-2 flex flex-wrap gap-1.5">
        <Button size="sm" variant="blue" onClick={onView}>View Workout</Button>
        <Button size="sm" onClick={onComplete} aria-pressed={done}>{done ? 'Undo' : 'Complete'}</Button>
      </div>
    </section>
  )
}

import type { Workout } from '../../types'
import { Badge, Button, Modal } from '../UI'
import { useApp } from '../../state/AppContext'

export function WorkoutModal({ workout, date, onClose }: { workout: Workout; date: string; onClose: () => void }) {
  const app = useApp()
  const done = app.completedWorkouts.some(c => c.date === date)
  return (
    <Modal open title={workout.name} onClose={onClose}>
      <div className="flex flex-wrap gap-1.5"><Badge tone="blue">{workout.category.replace('-', ' ')}</Badge><Badge>{workout.difficulty}</Badge>{workout.durationMin > 0 && <Badge>{workout.durationMin} min</Badge>}
        {workout.equipment.map(e => <Badge key={e}>{e === 'none' ? 'no equipment' : e}</Badge>)}</div>
      <p className="mt-3 text-sm">{workout.description}</p>
      {workout.exercises.length > 0 && (
        <ol className="mt-3 space-y-2">{workout.exercises.map(e => (
          <li key={e.name} className="rounded-lg border border-stone-200 p-2 text-sm">
            <p className="font-semibold">{e.name} <span className="font-normal text-stone-600">— {e.sets ? `${e.sets} × ` : ''}{e.reps ?? (e.seconds ? `${e.seconds >= 120 ? Math.round(e.seconds / 60) + ' min' : e.seconds + ' sec'}` : '')}</span></p>
            <p className="text-xs text-stone-600">{e.instructions}</p>
          </li>))}</ol>)}
      <p className="mt-3 text-xs text-stone-600">General fitness guidance, not medical advice. Stop if you feel pain, and check with a professional if you have an injury or health condition.</p>
      <div className="mt-4"><Button variant="blue" onClick={() => app.toggleWorkoutDone(date, workout.id)} aria-pressed={done}>{done ? '✓ Completed (undo)' : 'Mark Complete'}</Button></div>
    </Modal>
  )
}

import type { MealType, PlanDay } from '../../types'
import { mealById } from '../../data/meals'
import { workoutById } from '../../data/workouts'
import { MealSlot } from '../Meals/MealSlot'
import { WorkoutSlot } from '../Workouts/WorkoutSlot'
import { dayName, dayNum, iso } from '../../utils/dates'
import { useApp } from '../../state/AppContext'

export type PlanModal = { kind: 'details' | 'swap' | 'compare'; date: string; slot: MealType } | { kind: 'workout'; date: string }

export function DayCard({ day, open }: { day: PlanDay; open: (m: PlanModal) => void }) {
  const app = useApp()
  const today = day.date === iso(new Date())
  const workout = day.workoutId ? workoutById[day.workoutId] : undefined
  return (
    <article aria-label={`${dayName(day.date, true)} ${dayNum(day.date)}`} className={`rounded-2xl border bg-white p-3 shadow-sm ${today ? 'border-emerald-500 ring-1 ring-emerald-500' : 'border-stone-200'}`}>
      <h3 className="mb-2 flex items-baseline justify-between"><span className="font-bold uppercase tracking-wide">{dayName(day.date)} <span className="text-stone-500">{dayNum(day.date)}</span></span>{today && <span className="text-xs font-medium text-emerald-700">Today</span>}</h3>
      <div className="space-y-2">
        {(['lunch', 'dinner'] as const).map(slot => {
          const id = slot === 'lunch' ? day.lunchId : day.dinnerId
          return <MealSlot key={slot} slot={slot} date={day.date} meal={id ? mealById[id] : undefined}
            onDetails={() => open({ kind: 'details', date: day.date, slot })} onCompare={() => open({ kind: 'compare', date: day.date, slot })} onSwap={() => open({ kind: 'swap', date: day.date, slot })} />
        })}
        <WorkoutSlot workout={workout} done={app.completedWorkouts.some(c => c.date === day.date)}
          onView={() => open({ kind: 'workout', date: day.date })} onComplete={() => workout && app.toggleWorkoutDone(day.date, workout.id)} />
      </div>
    </article>
  )
}

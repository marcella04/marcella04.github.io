import { useState } from 'react'
import type { Meal, MealType } from '../../types'
import { Badge, Button, Modal } from '../UI'
import { useApp } from '../../state/AppContext'
import { mealAllergens } from '../../engine/nutritionCalculator'
import { ingredientById } from '../../data/ingredients'
import { money } from '../../utils/format'
import { familyOf } from '../../engine/unitConversion'

interface Props { meal: Meal; slot: MealType; date: string; onClose: () => void; onSwap: () => void; onCompare: () => void }
export function MealDetailsModal({ meal, slot, date, onClose, onSwap, onCompare }: Props) {
  const app = useApp()
  const [added, setAdded] = useState(false)
  const eaten = app.completedMeals.some(c => c.date === date && c.slot === slot)
  const fav = app.favorites.includes(meal.id)
  const allergens = mealAllergens(meal)
  const addToList = () => {
    app.shopping.restore(meal.ingredients.map(i => `${i.ingredientId}|${familyOf(i.unit)}`))
    meal.ingredients.filter(i => app.owned.includes(i.ingredientId)).forEach(i => app.shopping.toggleOwned(i.ingredientId))
    setAdded(true)
  }
  return (
    <Modal open title={meal.name} onClose={onClose} wide>
      <div className="flex flex-wrap gap-1.5">{meal.dietTags.map(t => <Badge key={t} tone="green">{t}</Badge>)}{meal.categories.map(c => <Badge key={c}>{c.replace('-', ' ')}</Badge>)}</div>
      <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-5">
        {([['Calories', `${meal.calories} kcal`], ['Protein', `${meal.protein} g`], ['Carbs', `${meal.carbs} g`], ['Fat', `${meal.fat} g`], ['Prep', meal.prepMinutes ? `${meal.prepMinutes} min` : 'None']] as const).map(([k, v]) => (
          <div key={k} className="rounded-lg bg-emerald-50 p-2"><dt className="text-xs text-stone-600">{k}</dt><dd className="font-semibold">{v}</dd></div>))}
      </dl>
      <p className="mt-2 text-xs text-stone-600">Nutrition values are estimates per serving. Estimated cost: {money(meal.estimatedCostPerServing)} per serving <Badge tone="violet">Estimated price</Badge></p>
      <p className="mt-2 text-sm"><strong>Allergen information:</strong> {allergens.length ? allergens.join(', ') : 'none declared'}. {meal.restaurant ? 'Restaurant meals vary — confirm with the restaurant.' : ''}</p>
      {meal.ingredients.length > 0 && (
        <div className="mt-3"><h3 className="font-semibold">Ingredients{meal.servings > 1 ? ` (recipe makes ${meal.servings} servings)` : ''}</h3>
          <ul className="mt-1 grid gap-x-6 text-sm sm:grid-cols-2">{meal.ingredients.map(i => <li key={i.ingredientId}>{i.quantity} {i.unit} {ingredientById[i.ingredientId]?.name ?? i.name}</li>)}</ul></div>)}
      <div className="mt-3"><h3 className="font-semibold">Preparation</h3><ol className="mt-1 list-decimal space-y-1 pl-5 text-sm">{meal.instructions.map((s, i) => <li key={i}>{s}</li>)}</ol></div>
      <p className="mt-3 text-sm"><strong>Suggested store chains (demo):</strong> {meal.suggestedStoreChains.length ? meal.suggestedStoreChains.join(', ') : 'n/a'}</p>
      {added && <p role="status" className="mt-2 text-sm text-teal-800">✓ Ingredients are on this week’s shopping list.</p>}
      <div className="mt-4 flex flex-wrap gap-2">
        <Button variant="primary" onClick={() => app.toggleMealEaten(date, slot, meal.id)} aria-pressed={eaten}>{eaten ? '✓ Eaten (undo)' : 'Mark as Eaten'}</Button>
        <Button onClick={() => app.toggleFavorite(meal.id)} aria-pressed={fav}>{fav ? '★ Favorited' : '☆ Favorite'}</Button>
        <Button onClick={onSwap}>Swap Meal</Button>
        <Button variant="teal" onClick={onCompare}>Compare Stores</Button>
        <Button onClick={addToList} disabled={!meal.ingredients.length}>Add to Shopping List</Button>
      </div>
    </Modal>
  )
}

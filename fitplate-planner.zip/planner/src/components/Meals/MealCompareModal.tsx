import type { Meal } from '../../types'
import { Modal } from '../UI'
import { StoreComparisonView } from '../Stores/StoreComparisonView'

export function MealCompareModal({ meal, onClose }: { meal: Meal; onClose: () => void }) {
  return (
    <Modal open title={`Compare stores: ${meal.name}`} onClose={onClose} wide>
      <p className="mb-3 text-xs text-stone-600">Checkout cost = whole packages for the full recipe ({meal.servings} serving{meal.servings > 1 ? 's' : ''}). Usage cost = only the quantity the recipe needs.</p>
      <StoreComparisonView requirements={meal.ingredients} servings={meal.servings} perLabel="per serving" />
    </Modal>
  )
}

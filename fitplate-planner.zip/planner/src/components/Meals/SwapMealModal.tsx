import { useMemo, useState } from 'react'
import type { Meal, MealType } from '../../types'
import { Badge, Button, EmptyState, Modal } from '../UI'
import { useApp } from '../../state/AppContext'
import { meals as allMeals } from '../../data/meals'
import { defaultContext, swapCandidates, swapModes, type SwapMode } from '../../engine/mealRecommendation'
import { money } from '../../utils/format'

export function SwapMealModal({ current, slot, date, onClose }: { current?: Meal; slot: MealType; date: string; onClose: () => void }) {
  const app = useApp()
  const [mode, setMode] = useState<SwapMode>('different')
  const p = app.profile!
  const weekMealIds = useMemo(() => app.plan?.days.flatMap(d => [d.lunchId, d.dinnerId]).filter(Boolean) as string[] ?? [], [app.plan])
  const list = useMemo(() => swapCandidates(allMeals, p, slot, current, mode,
    { ...defaultContext(p), recentMealIds: weekMealIds, favoriteIds: app.favorites, coverageByMeal: app.coverageByMeal }).slice(0, 6),
  [p, slot, current, mode, weekMealIds, app.favorites, app.coverageByMeal])
  return (
    <Modal open title={`Swap ${slot}`} onClose={onClose}>
      <p className="text-sm text-stone-600">Only this meal changes. Allergies and dietary restrictions always apply.</p>
      <div className="mt-3 flex flex-wrap gap-1.5" role="group" aria-label="Replacement mode">
        {swapModes.map(m => <Button key={m.id} size="sm" variant={mode === m.id ? 'primary' : 'secondary'} aria-pressed={mode === m.id} onClick={() => setMode(m.id)}>{m.label}</Button>)}
      </div>
      <ul className="mt-3 space-y-2">
        {list.map(({ meal, confidence }) => (
          <li key={meal.id} className="flex items-center justify-between gap-3 rounded-xl border border-stone-200 p-3">
            <div>
              <p className="text-sm font-semibold">{meal.name}</p>
              <p className="text-xs text-stone-600">{meal.calories} kcal · {meal.protein}g protein · est. {money(meal.estimatedCostPerServing)} · {meal.prepMinutes ? `${meal.prepMinutes} min` : 'no prep'}</p>
              {confidence === 'low' && !meal.restaurant && <Badge tone="violet">No local price data</Badge>}
            </div>
            <Button size="sm" variant="primary" onClick={() => { app.setSlotMeal(date, slot, meal.id); onClose() }}>Use this</Button>
          </li>))}
      </ul>
      {!list.length && <div className="mt-3"><EmptyState title="No compatible options">Nothing in the sample database matches this mode with your allergies and diet. Try another mode.</EmptyState></div>}
    </Modal>
  )
}

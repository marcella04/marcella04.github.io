import { useMemo } from 'react'
import type { Meal, MealType } from '../../types'
import { Badge, Button, DistanceLabel, PriceLabel } from '../UI'
import { useApp } from '../../state/AppContext'
import { useComparison } from '../../hooks/useComparison'
import { money } from '../../utils/format'

export function MealSlot({ meal, slot, date, onDetails, onCompare, onSwap }: {
  meal?: Meal; slot: MealType; date: string; onDetails: () => void; onCompare: () => void; onSwap: () => void
}) {
  const app = useApp()
  const reqs = useMemo(() => meal?.ingredients ?? [], [meal])
  const cmp = useComparison(reqs, meal?.servings ?? 1)
  const eaten = app.completedMeals.some(c => c.date === date && c.slot === slot)
  const title = slot === 'lunch' ? 'Lunch' : 'Dinner'
  if (!meal) return <section className="rounded-xl bg-stone-50 p-3"><h4 className="text-xs font-semibold uppercase text-emerald-800">{title}</h4><p className="mt-1 text-sm text-stone-600">No compatible meal found.</p></section>
  const best = cmp?.result.best
  return (
    <section aria-label={`${title}: ${meal.name}`} className="rounded-xl bg-emerald-50/70 p-3">
      <div className="flex items-center justify-between"><h4 className="text-xs font-semibold uppercase tracking-wide text-emerald-800">{title}</h4>{eaten && <Badge tone="green">✓ Eaten</Badge>}</div>
      <p className="mt-1 text-sm font-semibold leading-snug">{meal.name}</p>
      <p className="mt-0.5 text-xs text-stone-700">{meal.calories} kcal · {meal.protein}g protein</p>
      <p className="text-xs text-stone-700">Est. {money(meal.estimatedCostPerServing)} per serving</p>
      <div className="mt-1 min-h-[1rem] text-xs text-stone-600">
        {meal.restaurant ? <span>{meal.restaurant}</span>
          : best ? <span>Best nearby option: {best.store.name}, <DistanceLabel miles={best.distanceMiles} /> {!cmp!.result.confident && <em>(limited data)</em>} <PriceLabel type={best.priceType} /></span>
          : app.localOn ? null : <span>Enable location to compare stores.</span>}
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5">
        <Button size="sm" variant="primary" onClick={onDetails}>Details</Button>
        <Button size="sm" variant="teal" onClick={onCompare}>Compare Stores</Button>
        <Button size="sm" onClick={onSwap}>Swap</Button>
      </div>
    </section>
  )
}
